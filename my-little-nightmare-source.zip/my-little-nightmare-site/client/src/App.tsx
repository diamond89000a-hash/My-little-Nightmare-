// Direction artistique : cabinet de curiosités nocturne — le shell global reste sombre, éditorial et peu bavard.
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Intro from "./pages/Intro";
import Home from "./pages/Home";
import Nightmare from "./pages/Nightmare";
import AudioDiary from "./pages/AudioDiary";
import Evidence from "./pages/Evidence";
import Pantheon from "./pages/Pantheon";
import HorrorArchive from "@/pages/HorrorArchive";
import InvocationRitual from "@/pages/InvocationRitual";
import MinecraftSkins from "./pages/MinecraftSkins";
import NightmareArchive from "./pages/NightmareArchive";
import NightmareLetterHunt from "./components/NightmareLetterHunt";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Intro} />
      <Route path="/site" component={Home} />
      <Route path="/cauchemar/:slug" component={Nightmare} />
      <Route path="/journal" component={AudioDiary} />
      <Route path="/preuves" component={Evidence} />
      <Route path="/dossier-interdit" component={Pantheon} />
      <Route path="/horror" component={HorrorArchive} />
      <Route path="/rituel" component={InvocationRitual} />
      <Route path="/minecraft" component={MinecraftSkins} />
      <Route path="/nightmare-archive" component={NightmareArchive} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
          <NightmareLetterHunt />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
