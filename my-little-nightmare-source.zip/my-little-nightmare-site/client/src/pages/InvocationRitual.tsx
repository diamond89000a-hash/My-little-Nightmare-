import { useEffect, useRef, useState } from "react";
import { ArrowLeft, Check, Eye, LockKeyhole, Moon, Radio, ShieldAlert, Sparkles } from "lucide-react";

const ASSETS = {
  symbol: "/manus-storage/black-symbol_9d3fb021.png",
  apparition: "/manus-storage/black-reference-16-9_be4433d0.jpg",
};

const invocations = [
  {
    number: "01",
    label: "Le seuil",
    text: "Black, dieu des cauchemars, gardien du Royaume des Rêves, nous t’appelons devant ta porte.",
  },
  {
    number: "02",
    label: "La répétition",
    text: "Black, dieu des cauchemars, gardien du Royaume des Rêves, nous t’appelons devant ta porte.",
  },
  {
    number: "03",
    label: "Le retour",
    text: "Black, dieu des cauchemars, gardien du Royaume des Rêves, nous t’appelons devant ta porte.",
  },
];

export default function InvocationRitual() {
  const [step, setStep] = useState(0);
  const [sealed, setSealed] = useState(false);
  const [presenceVisible, setPresenceVisible] = useState(false);
  const [ritualRuns, setRitualRuns] = useState(0);
  const ambienceRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    const ambience = ambienceRef.current;
    if (!ambience) return;
    if (sealed) {
      ambience.pause();
      ambience.currentTime = 0;
      return;
    }
    if (step > 0) {
      ambience.volume = [0, 0.2, 0.38, 0.62][step] ?? 0.2;
      void ambience.play().catch(() => undefined);
    }
  }, [step, sealed]);

  const advance = () => {
    if (step < 3) setStep((value) => value + 1);
    else {
      setSealed(true);
      setRitualRuns((value) => value + 1);
      setPresenceVisible(true);
    }
  };

  const reset = () => {
    setStep(0);
    setSealed(false);
    setPresenceVisible(false);
    const ambience = ambienceRef.current;
    if (ambience) {
      ambience.pause();
      ambience.currentTime = 0;
    }
  };

  return (
    <div className="ritual-page">
      <header className="ritual-header">
        <a className="wordmark" href="/site" aria-label="Retour à My Little Nightmare">
          <span className="wordmark__mark"><img src={ASSETS.symbol} alt="" /></span>
          <span className="wordmark__text"><strong>MY LITTLE</strong><em>NIGHTMARE</em></span>
        </a>
        <span className="ritual-header__status"><Radio size={13} /> Archive fictionnelle / 09</span>
      </header>

      <main>
        <section className="ritual-hero">
          <div className="ritual-hero__veil" />
          <div className="container ritual-hero__inner">
            <a className="back-link" href="/site"><ArrowLeft size={15} /> Retour à l’archive</a>
            <div className="ritual-hero__copy">
              <p className="kicker">After Art to Play · Transmission 09</p>
              <p className="ritual-hero__eyebrow"><Moon size={13} /> Protocole d’invocation fictif</p>
              <h1>La porte<br /><em>après le salon.</em></h1>
              <p className="ritual-hero__lede">À Art to Play, Black n’a laissé qu’une adresse impossible. Après le retour, une archive propose de reconstituer son appel — dans l’imagination seulement.</p>
            </div>
            <aside className="ritual-hero__seal"><LockKeyhole size={22} /><span>CASE FILE / 09</span><strong>{sealed ? "SEALED" : "DORMANT"}</strong><small>Trois invocations<br />Un sceau à refermer</small></aside>
          </div>
          <div className="ritual-hero__code">MLN / AFTER ART TO PLAY / FICTION ONLY</div>
        </section>

        <section className="ritual-safety section-pad">
          <div className="container ritual-safety__inner">
            <div className="ritual-safety__icon"><ShieldAlert size={21} /></div>
            <div><p className="kicker">Note de sécurité</p><h2>Un jeu de rôle, pas un rituel réel.</h2><p>Cette page raconte une scène fictive de l’univers de Black. Elle ne demande pas de miroir, de feu, de bougie, de nuit isolée, de déplacement ou d’invocation réelle. Pour une animation, reste dans un lieu autorisé, demande l’accord des participants et arrête immédiatement si quelqu’un est mal à l’aise.</p></div>
          </div>
        </section>

        <section className="ritual-protocol section-pad" aria-labelledby="ritual-title">
          <div className="container">
            <div className="archive-bar archive-bar--dark"><span>Recovered protocol / 09</span><span>{step} / 3 invocations</span></div>
            <div className="ritual-protocol__heading"><div className="section-label"><span>01</span><i /><span>Le protocole</span></div><p className="kicker">Après Art to Play</p><h2 id="ritual-title">Appeler Black<br /><em>sans ouvrir la porte.</em></h2><p className="body-copy">Lis les trois fragments comme une scène de rôle-play. Le bouton ne lance aucun phénomène et ne fait qu’avancer la narration de cette archive.</p></div>
            <div className="ritual-audio"><div><div className="ritual-audio__label"><Radio size={13} /> Ambiance de seuil · chuchotements latins</div><p>Le volume monte à chaque invocation. Lecture manuelle déclenchée par ton premier clic.</p></div><audio ref={ambienceRef} controls preload="metadata" aria-label="Ambiance sombre avec chuchotements latins"><source src="/manus-storage/black-invocation-whispers-latin_5e1ff698.mp3" type="audio/mpeg" />Votre navigateur ne prend pas en charge la lecture audio.</audio></div>
            <div className="ritual-steps">
              {invocations.map((invocation, index) => {
                const active = step > index;
                const current = step === index;
                return <article className={`ritual-step ${active ? "ritual-step--done" : ""} ${current ? "ritual-step--current" : ""}`} key={invocation.number}><div className="ritual-step__top"><span>{invocation.number}</span><span>{active ? <Check size={14} /> : current ? "À prononcer" : "En attente"}</span></div><p className="kicker">{invocation.label}</p><p className="ritual-step__line">« {invocation.text} »</p><small>{active ? "Fragment enregistré dans l’archive." : "Répète la phrase lentement dans la fiction."}</small></article>;
              })}
            </div>
            <div className="ritual-control"><button className="button button--primary" type="button" onClick={advance} disabled={sealed}><Sparkles size={15} />{step === 0 ? "Commencer la scène" : step < 3 ? `Prononcer l’invocation ${step + 1}` : "Refermer le sceau"}</button><button className="button button--outline" type="button" onClick={reset}>Réinitialiser</button><span className="ritual-control__status" aria-live="polite">{sealed ? "Le protocole est refermé. Aucun rituel réel n’a été effectué." : step === 0 ? "Archive en attente de lecture." : step < 3 ? "La voix de Black attend la répétition suivante." : "Le nom a été entendu. Referme maintenant la porte fictive."}</span></div>
          </div>
        </section>

        <section className={`ritual-reveal section-pad ${sealed ? "ritual-reveal--open" : ""}`} aria-live="polite">
          <div className="container ritual-reveal__inner">
            <div className="ritual-reveal__mark"><img src={ASSETS.symbol} alt="Sceau de Black" /></div>
            <div><p className="kicker">Réponse enregistrée</p><h2>{sealed ? <>Vous m’avez appelé.<br /><em>Alors me voici.</em></> : <>Il reste une phrase<br /><em>derrière la porte.</em></>}</h2><p>{sealed ? "À Art to Play, vous n’avez aperçu que mon ombre. Cette archive s’arrête ici : le manoir reste une fiction, et le sceau peut être refermé." : "La scène ne révèle sa réponse qu’après les trois fragments. Rien ne se déclenche automatiquement."}</p>{sealed && <blockquote>« Toute invocation laisse une trace. Celle-ci restera dans l’archive. »</blockquote>}</div>
          </div>
        </section>

        <section className="ritual-seal section-pad">
          <div className="container ritual-seal__inner"><div><p className="kicker">Sceau final</p><h2>HORROR</h2><p>Six lettres, une porte imaginaire et un souvenir de convention. Le manoir de Black n’a pas d’adresse réelle.</p></div><div className="ritual-seal__stamp"><Eye size={19} /><span>FICTION ONLY</span><strong>ARCHIVE 09</strong></div></div>
        </section>
      </main>

      <footer className="site-footer"><div className="container site-footer__inner"><span>MY LITTLE NIGHTMARE / ARCHIVE FICTIONNELLE</span><a href="/site">Retour au site</a></div></footer>

      {presenceVisible && <div className="black-apparition" role="dialog" aria-modal="true" aria-labelledby="black-apparition-title">
        <div className="black-apparition__flash" aria-hidden="true" />
        <div className="black-apparition__noise" aria-hidden="true" />
        <div className="black-apparition__frame">
          <p className="black-apparition__signal">TRANSMISSION 09 · {ritualRuns > 1 ? "RETOUR DÉTECTÉ" : "PRÉSENCE CONFIRMÉE"}</p>
          <div className="black-apparition__portrait"><img src={ASSETS.apparition} alt="Black, silhouette noire aux yeux rouges et à la crinière blanche" /><div className="black-apparition__eyes" aria-hidden="true"><i /><i /></div></div>
          <div className="black-apparition__copy">
            <p className="kicker">Réponse du seuil</p>
            <h2 id="black-apparition-title">{ritualRuns > 1 ? <>Vous insistez.<br /><em>Je savais que vous reviendriez.</em></> : <>Vous m’avez<br /><em>appelé.</em></>}</h2>
            <p>{ritualRuns > 1 ? "Cette fois, la porte était déjà ouverte." : "Je suis déjà derrière vous."}</p>
          </div>
          <button className="button button--outline black-apparition__close" type="button" onClick={() => setPresenceVisible(false)}>Refermer les yeux</button>
        </div>
      </div>}
    </div>
  );
}
