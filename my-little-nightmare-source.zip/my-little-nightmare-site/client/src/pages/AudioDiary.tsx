// Direction artistique : journal audio retrouvé — charbon bleuté, ivoire d’archive, cramoisi d’alerte et composition verticale comme une confession extraite du dossier.
import { useRef, useState } from "react";
import { ArrowLeft, ArrowUpRight, Headphones, Pause, Play, Radio } from "lucide-react";

const ASSETS = {
  portrait: "/manus-storage/black-profile_0707698f.png",
  symbol: "/manus-storage/black-symbol_9d3fb021.png",
  diary: "/manus-storage/black-audio-diary_b8b94532.wav",
};

export default function AudioDiary() {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const toggleAudio = async () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (audio.paused) {
      await audio.play();
    } else {
      audio.pause();
    }
  };

  return (
    <div className="diary-page">
      <header className="diary-header">
        <a className="wordmark" href="/site" aria-label="Retour à My Little Nightmare"><span className="wordmark__mark"><img src={ASSETS.symbol} alt="" /></span><span className="wordmark__text"><strong>MY LITTLE</strong><em>NIGHTMARE</em></span></a>
        <span className="diary-header__signal"><Radio size={13} /> Journal privé / 01</span>
      </header>
      <main>
        <section className="diary-hero">
          <div className="diary-hero__image"><img src={ASSETS.portrait} alt="Portrait nocturne de Black" /></div>
          <div className="diary-hero__veil" />
          <div className="container diary-hero__content">
            <a className="back-link" href="/site#black"><ArrowLeft size={15} /> Retour au dossier de Black</a>
            <p className="kicker">Recovered audio / 01 · Écoute recommandée au casque</p>
            <p className="diary-hero__eyebrow">Journal de Black</p>
            <h1>Ce qui reste<br /><em>après le rêve.</em></h1>
            <p className="diary-hero__intro">Une confession enregistrée dans l’intervalle entre deux mondes. La voix n’a pas été identifiée au moment de la récupération.</p>
          </div>
          <span className="diary-hero__code">MLN / AUDIO / 001</span>
        </section>
        <section className="diary-player section-pad">
          <div className="container diary-player__grid">
            <div className="section-label"><span>01</span><i /><span>Écoute</span></div>
            <div className="diary-player__main">
              <p className="kicker">Entrée numéro un · 01:29</p>
              <h2>Il a laissé<br /><em>un message.</em></h2>
              <p className="body-copy">Mets le son. Ne cherche pas à identifier la voix. Elle sait déjà que tu écoutes.</p>
              <div className="diary-player__card">
                <div className="diary-player__card-top"><span><Headphones size={14} /> Bande magnétique retrouvée</span><span>BLACK / PRIVATE</span></div>
                <button className={`diary-play ${isPlaying ? "diary-play--active" : ""}`} type="button" onClick={toggleAudio} aria-label={isPlaying ? "Mettre le journal audio en pause" : "Lire le journal audio"}><span>{isPlaying ? <Pause size={18} /> : <Play size={18} />}</span><strong>{isPlaying ? "Lecture en cours" : "Écouter l’entrée"}</strong><ArrowUpRight size={16} /></button>
                <audio ref={audioRef} controls preload="metadata" onPlay={() => setIsPlaying(true)} onPause={() => setIsPlaying(false)} onEnded={() => setIsPlaying(false)} aria-label="Journal audio de Black, entrée numéro un"><source src={ASSETS.diary} type="audio/wav" />Votre navigateur ne prend pas en charge la lecture audio.</audio>
                <p className="diary-player__note">La lecture ne démarre jamais automatiquement.</p>
              </div>
            </div>
            <aside className="diary-player__stamp"><img src={ASSETS.symbol} alt="" /><span>VOICE TRACE</span><strong>BLACK</strong><small>Présence confirmée<br />à 03:13</small></aside>
          </div>
        </section>
        <section className="diary-transcript section-pad">
          <div className="container diary-transcript__grid">
            <div className="section-label"><span>02</span><i /><span>Transcription</span></div>
            <article><p className="kicker">Texte récupéré · fragments vérifiés</p><h2>La voix<br /><em>se souvient.</em></h2><p>Ils pensent que les cauchemars commencent quand ils ferment les yeux. C’est faux. Ils commencent bien avant… dans les reflets, dans les écrans, dans les secondes où personne ne regarde.</p><p>Les humains portent leurs peurs comme des portes mal fermées. Il suffit d’attendre. Il suffit d’écouter.</p><p>Je ne suis pas le cauchemar. Je suis ce qui reste… quand le rêve refuse de finir.</p><div className="diary-transcript__line"><span>Dernier signal</span><strong>« Fin de l’entrée. Pour l’instant. »</strong></div></article>
          </div>
        </section>
        <section className="diary-next">
          <div className="container"><div className="diary-next__top"><span className="section-label"><span>Archive</span><i /><span>Sortie</span></span><span className="diary-next__status"><Radio size={14} /> Signal dormant</span></div><div className="diary-next__links"><a href="/site#black" className="button button--outline"><ArrowLeft size={15} /> Retour au dossier de Black</a><a href="/site" className="arrow-link">Fermer le journal <ArrowUpRight size={16} /></a></div></div>
        </section>
      </main>
      <footer className="site-footer"><div className="container site-footer__inner"><span>MY LITTLE NIGHTMARE / AUDIO ARCHIVE</span><span className="site-footer__code">JOURNAL / 01</span></div></footer>
    </div>
  );
}
