import { FormEvent, useEffect, useMemo, useState } from "react";
import { ArrowLeft, FileWarning, KeyRound, LockKeyhole, Radio } from "lucide-react";

const STORAGE_PREFIX = "mln-nightmare-code-";
const UNLOCK_KEY = "mln-nightmare-archive-unlocked";
const CODE = "NIGHTMARE";

function playNightmareUnlockSound() {
  const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextClass) return;
  const context = new AudioContextClass();
  const master = context.createGain();
  const filter = context.createBiquadFilter();
  const bass = context.createOscillator();
  const pulse = context.createOscillator();
  const noise = context.createBufferSource();
  const noiseGain = context.createGain();
  const now = context.currentTime;

  master.gain.setValueAtTime(0.0001, now);
  master.gain.exponentialRampToValueAtTime(0.24, now + 0.18);
  master.gain.exponentialRampToValueAtTime(0.0001, now + 3.5);
  filter.type = "lowpass";
  filter.frequency.setValueAtTime(240, now);
  filter.frequency.exponentialRampToValueAtTime(880, now + 1.1);
  filter.frequency.exponentialRampToValueAtTime(110, now + 3.4);
  bass.type = "sawtooth";
  bass.frequency.setValueAtTime(49, now);
  bass.frequency.exponentialRampToValueAtTime(31, now + 3.3);
  pulse.type = "sine";
  pulse.frequency.setValueAtTime(73, now);
  pulse.frequency.exponentialRampToValueAtTime(42, now + 3.2);
  const buffer = context.createBuffer(1, context.sampleRate * 3.5, context.sampleRate);
  const data = buffer.getChannelData(0);
  for (let index = 0; index < data.length; index += 1) data[index] = (Math.random() * 2 - 1) * 0.7;
  noise.buffer = buffer;
  noiseGain.gain.setValueAtTime(0.0001, now);
  noiseGain.gain.exponentialRampToValueAtTime(0.12, now + 0.25);
  noiseGain.gain.exponentialRampToValueAtTime(0.0001, now + 3.4);
  bass.connect(filter);
  pulse.connect(filter);
  noise.connect(noiseGain).connect(filter);
  filter.connect(master).connect(context.destination);
  bass.start(now);
  pulse.start(now);
  noise.start(now);
  bass.stop(now + 3.5);
  pulse.stop(now + 3.5);
  noise.stop(now + 3.5);
  window.setTimeout(() => void context.close(), 3900);
}

const sections = [
  { number: "01", title: "Description physique", paragraphs: ["L’entité connue sous le nom de Black adopte l’apparence d’un alicorne mâle au pelage d'un noir absolu, semblant absorber toute source de lumière environnante.", "Signes distinctifs : une crinière et une queue bicolores — noires et d'un blanc éclatant —, des ailes blanches contrastant violemment avec son corps d'encre, ainsi que deux pupilles d'un rouge perçant.", "Particularité vestimentaire : l’entité porte systématiquement un élégant costume sombre accompagné d’un nœud papillon rouge vif. Ce détail vestimentaire apparaît souvent comme un avertissement dans les songes de ses victimes avant sa manifestation complète."] },
  { number: "02", title: "Origine et nature", paragraphs: ["Contrairement aux créatures ordinaires d’Equestria, Black n’est pas né de chair et de sang. Il est une entité primordiale née de l’équilibre naturel entre la lumière et l'ombre : le Dieu des Cauchemars.", "Pendant des millénaires, Black a existé en marge du royaume, se nourrissant silencieusement des peurs, des angoisses et des mauvais rêves des habitants d’Equestria. Ce cycle maintenait son pouvoir stable sans qu'il n'ait besoin d'intervenir directement dans le monde éveillé."] },
  { number: "03", title: "Motif d’hostilité envers les Mane Six", paragraphs: ["L’avènement des Éléments d'Harmonie et les victoires répétées de Twilight Sparkle et de ses amies ont profondément bouleversé l’équilibre émotionnel d’Equestria. L'amitié, la joie et la paix se sont répandues à un point tel que les cauchemars se sont faits extrêmement rares.", "Privé de sa source d’énergie vitale et condamné à s'affaiblir dans l'oubli, Black a développé une haine profonde envers les six porteuses des Éléments. Son objectif n’est pas une simple vengeance : il cherche à briser psychologiquement les Mane Six en retournant leurs propres peurs contre elles afin d’éteindre définitivement la magie de l’Harmonie."] },
  { number: "04", title: "Pouvoirs et capacités recensés", paragraphs: ["Manipulation onirique absolue : Black possède une autorité totale sur le monde des cauchemars, surpassant même les capacités de la Princesse Luna dans les zones d'ombre profonde.", "Matérialisation des phobies : il peut lire l’esprit d’une cible et recréer ses pires angoisses avec un réalisme sensoriel total — douleur, odeurs et hallucinations.", "Débordement physique : lorsque sa victime est suffisamment affaiblie mentalement, les traumatismes subis dans le rêve commencent à laisser des traces dans le monde réel — griffures, murmures et paralysie du sommeil.", "Immortalité conceptuelle : tant que la peur existera dans le cœur d'un seul être vivant, Black ne pourra jamais être totalement détruit."] },
];

export default function NightmareArchive() {
  const [code, setCode] = useState("");
  const [unlocked, setUnlocked] = useState(false);
  const [error, setError] = useState(false);
  const [found, setFound] = useState<string[]>([]);
  const [unlockAnimation, setUnlockAnimation] = useState(false);

  useEffect(() => {
    const collected = ["N", "I", "G", "H", "T", "M", "A", "R", "E"].filter((letter) => window.localStorage.getItem(`${STORAGE_PREFIX}${letter}`) === "true");
    setFound(collected);
    setUnlocked(window.localStorage.getItem(UNLOCK_KEY) === "true");
  }, []);

  const progress = useMemo(() => found.length, [found]);
  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (code.trim().toUpperCase() === CODE && progress === 9) {
      window.localStorage.setItem(UNLOCK_KEY, "true");
      setUnlocked(true);
      setError(false);
      playNightmareUnlockSound();
      setUnlockAnimation(true);
      window.setTimeout(() => setUnlockAnimation(false), 6200);
    } else {
      setError(true);
    }
  };

  return (
    <div className="nightmare-archive-page">
      <header className="nightmare-archive-header">
        <a className="wordmark" href="/site" aria-label="Retour à My Little Nightmare"><span className="wordmark__mark">◉</span><span className="wordmark__text"><strong>MY LITTLE</strong><em>NIGHTMARE</em></span></a>
        <span className="nightmare-archive-header__status"><Radio size={13} /> Archive royale / Omega</span>
      </header>
      <main>
        <section className="nightmare-archive-hero">
          <div className="container nightmare-archive-hero__inner">
            <a className="back-link" href="/site"><ArrowLeft size={15} /> Retour au site</a>
            <p className="kicker">Archives royales de Canterlot · accès restreint</p>
            <p className="nightmare-archive-hero__eyebrow"><LockKeyhole size={13} /> Sous scellés de la Princesse Luna</p>
            <h1>Le dossier<br /><em>Black.</em></h1>
            <p className="nightmare-archive-hero__lede">Une présence a dispersé neuf lettres dans les marges du site. Retrouvez-les, puis prononcez le code qui ouvre le dossier classifié.</p>
            <aside className="nightmare-archive-seal"><FileWarning size={20} /><span>NIVEAU OMEGA</span><strong>{unlocked ? "OPEN" : "SEALED"}</strong><small>{progress} / 9 lettres retrouvées<br />Code requis : NIGHTMARE</small></aside>
          </div>
        </section>
        <section className="nightmare-archive-lock section-pad">
          <div className="container nightmare-archive-lock__grid">
            <div className="nightmare-archive-lock__main">
              <p className="kicker">Classification : entité primordiale / menace active</p>
              <h2>Reconstituez<br /><em>le cauchemar.</em></h2>
              <p className="body-copy">Les fragments sont dissimulés sur plusieurs pages. Cliquez sur les marques discrètes qui vous observent pour former le mot secret.</p>
              <div className="nightmare-code-progress" aria-label={`${progress} lettres sur 9 retrouvées`}>{["N", "I", "G", "H", "T", "M", "A", "R", "E"].map((letter) => <span className={found.includes(letter) ? "nightmare-code-progress__found" : ""} key={letter}>{found.includes(letter) ? letter : "·"}</span>)}</div>
              <form className="nightmare-code-form" onSubmit={handleSubmit}><label htmlFor="nightmare-code">Code d’archive</label><div><input id="nightmare-code" value={code} onChange={(event) => { setCode(event.target.value); setError(false); }} placeholder={progress === 9 ? "NIGHTMARE" : "Neuf lettres requises"} maxLength={9} disabled={progress < 9 || unlocked} autoComplete="off" /><button className="button button--primary" type="submit" disabled={progress < 9 || unlocked}><KeyRound size={15} /> {unlocked ? "Dossier ouvert" : "Ouvrir le dossier"}</button></div><p className={error ? "nightmare-code-form__error" : "nightmare-code-form__hint"}>{unlocked ? "Accès accordé. La transcription royale est disponible." : error ? "Le code est incorrect ou les lettres ne sont pas complètes." : `Progression : ${progress} / 9 fragments.`}</p></form>
            </div>
            <aside className="nightmare-archive-note"><span>NOTE / LUNA</span><blockquote>« On ne tue pas un cauchemar. On ne fait que le repousser jusqu’à la prochaine nuit. »</blockquote></aside>
          </div>
        </section>
        {unlocked && <section className="nightmare-dossier section-pad"><div className="container"><div className="archive-bar archive-bar--dark"><span>MLN-000 / LE DOSSIER BLACK</span><span>Menace active dans le plan astral</span></div><div className="nightmare-dossier__intro"><p className="kicker">Archives royales de Canterlot · transcription autorisée</p><h2>Entité primordiale<br /><em>Dieu des Cauchemars.</em></h2><p>Le document ci-dessous a été conservé sous scellés après l’incident de Ponyville.</p></div><div className="nightmare-dossier__sections">{sections.map((section) => <article key={section.number}><span>{section.number}</span><div><p className="kicker">Dossier Black</p><h3>{section.title}</h3>{section.paragraphs.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}</div></article>)}</div><div className="nightmare-dossier__luna"><p className="kicker">05 · Note de la Princesse Luna</p><blockquote>« Nous pensions que la lumière des Éléments d'Harmonie l'avait renvoyé dans le néant. Mais lorsque je veille sur la nuit, je sens encore son regard rouge fixé sur Equestria depuis les abysses du sommeil. Que les futures générations gardent ce dossier scellé : on ne tue pas un cauchemar, on ne fait que le repousser jusqu’à la prochaine nuit. »</blockquote></div></div></section>}
      </main>
      <footer className="site-footer"><div className="container site-footer__inner"><span>ARCHIVE FICTIONNELLE / CANTERLOT</span><span className="site-footer__code">NIGHTMARE / {unlocked ? "OPEN" : `${progress}/09`}</span></div></footer>
      {unlockAnimation && <div className="nightmare-unlock-sequence" role="dialog" aria-modal="true" aria-labelledby="nightmare-unlock-title"><div className="nightmare-unlock-sequence__noise" /><div className="nightmare-unlock-sequence__scanlines" /><div className="nightmare-unlock-sequence__eye nightmare-unlock-sequence__eye--left" /><div className="nightmare-unlock-sequence__eye nightmare-unlock-sequence__eye--right" /><div className="nightmare-unlock-sequence__content"><span className="nightmare-unlock-sequence__signal">SIGNAL CONTAMINÉ · MLN-000</span><h2 id="nightmare-unlock-title">NIGHTMARE</h2><p>Le sceau a reconnu ta voix.</p><strong>IL EST DERRIÈRE TOI.</strong></div><button className="nightmare-unlock-sequence__close" type="button" onClick={() => setUnlockAnimation(false)}>Fermer l’apparition</button></div>}
    </div>
  );
}
