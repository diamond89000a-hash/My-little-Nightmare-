// Direction artistique : cabinet de curiosités nocturne — composition éditoriale asymétrique, ivoire sur charbon bleuté, cramoisi réservé aux signaux de Black.
import { useEffect, useRef, useState } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  BookOpen,
  ChevronRight,
  Eye,
  Menu,
  Moon,
  Radio,
  ScanLine,
  Sparkles,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";

const CHANNEL_URL = "https://youtube.com/@alwm7505?si=cFcFc5ABGvNcKr0x";

const ASSETS = {
  hero: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/my-little-nightmare-hero_670b7a46.png",
  library: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/nightmare-library_abafbcba.png",
  realWorld: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/real-world-invasion_d9870c55.png",
  symbol: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-symbol_9d3fb021.png",
  origin: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-origin_657f0123.png",
  profile: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-profile_0707698f.png",
  angry: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-angry_874f8495.png",
  sad: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-sad_1dede4f5.png",
  joyful: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-joyful_95143773.png",
  afraid: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-afraid_34657315.png",
  crossover: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/crossover_df6cfff7.png",
  theme: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/my-little-nightmare-theme_c7879d5b.wav",
  signalVideo: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-signal-8s_7d77a482.mp4",
};

const gallery = [
  { src: ASSETS.origin, label: "L’apparition", kicker: "Planche 01", alt: "Black au centre d’un cercle de cauchemars" },
  { src: ASSETS.profile, label: "Le visage", kicker: "Portrait signalé", alt: "Portrait rapproché de Black aux yeux rouges" },
  { src: ASSETS.afraid, label: "La peur retourne", kicker: "Planche 03", alt: "Black effrayé dans une forêt face à une silhouette" },
  { src: ASSETS.sad, label: "Après le rêve", kicker: "Fragment sensible", alt: "Black triste sous la pluie" },
  { src: ASSETS.joyful, label: "Le masque tombe", kicker: "Fragment rare", alt: "Black joyeux dans un champ fleuri" },
  { src: ASSETS.crossover, label: "Le conseil noir", kicker: "Transmission 06", alt: "Black entouré de créatures de creepypasta" },
];

const nightmares = [
  { slug: "twilight", number: "01", title: "Les pages vierges", text: "Twilight ouvre sa bibliothèque et découvre que chaque histoire a disparu. Il ne reste que le bruit d’une page que personne ne tourne.", tag: "Twilight Sparkle" },
  { slug: "pinkie", number: "02", title: "Le sucre rouge", text: "Pinkie prépare des cupcakes à la fraise. Quand le four sonne, la recette n’est plus la même — et le sous-sol non plus.", tag: "Pinkie Pie · clin d’œil à Cupcakes" },
  { slug: "rainbow", number: "03", title: "Le ciel immobile", text: "Rainbow Dash bat des ailes, mais le monde refuse de la laisser décoller. Quelque chose vole pourtant plus haut qu’elle.", tag: "Rainbow Dash" },
  { slug: "rarity", number: "04", title: "La dernière collection", text: "Rarity crée les plus belles robes de sa vie. Personne ne les regarde, et son reflet commence à changer.", tag: "Rarity" },
  { slug: "fluttershy", number: "05", title: "La cabane", text: "Fluttershy suit une trace rouge jusqu’à une cabane. Derrière la porte, une autre version d’elle l’attend déjà.", tag: "Fluttershy · écho de shed.mov" },
  { slug: "applejack", number: "06", title: "La récolte noire", text: "Applejack tente de protéger sa ferme, mais sa colère prend racine et ne reconnaît plus ses propres alliées.", tag: "Applejack" },
];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeImage, setActiveImage] = useState<(typeof gallery)[number] | null>(null);
    const [signalOn, setSignalOn] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const handleSignalToggle = async () => {
    const audio = audioRef.current;
    const video = videoRef.current;
    if (!audio || !video) return;
    if (signalOn) {
      audio.pause();
      video.pause();
      setSignalOn(false);
      return;
    }
    audio.currentTime = 0;
    video.currentTime = 0;
    const [audioResult, videoResult] = await Promise.allSettled([audio.play(), video.play()]);
    if (audioResult.status === "fulfilled" && videoResult.status === "fulfilled") {
      setSignalOn(true);
    } else {
      audio.pause();
      video.pause();
      setSignalOn(false);
    }
  };
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setActiveImage(null);
        setMenuOpen(false);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <header className={`site-header ${menuOpen ? "site-header--open" : ""}`}>
        <a className="wordmark" href="#top" onClick={closeMenu} aria-label="Retour au début de My Little Nightmare">
          <span className="wordmark__mark"><img src={ASSETS.symbol} alt="" /></span>
          <span className="wordmark__text"><strong>MY LITTLE</strong><em>NIGHTMARE</em></span>
        </a>
        <button className="mobile-toggle" type="button" onClick={() => setMenuOpen((value) => !value)} aria-label={menuOpen ? "Fermer le menu" : "Ouvrir le menu"} aria-expanded={menuOpen}>
          {menuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
        <nav className={`site-nav ${menuOpen ? "site-nav--visible" : ""}`} aria-label="Navigation principale">
          <a href="#dossier" onClick={closeMenu}><span>01</span>Dossier</a>
          <a href="#black" onClick={closeMenu}><span>02</span>Black</a>
          <a href="#cauchemars" onClick={closeMenu}><span>03</span>Cauchemars</a>
          <a href={import.meta.env.BASE_URL + "preuves"} onClick={closeMenu}><span>04</span>Preuves</a>
          <a href="#galerie" onClick={closeMenu}><span>05</span>Galerie</a>
          <a href={import.meta.env.BASE_URL + "journal"} onClick={closeMenu}><span>06</span>Journal audio</a>
          <a href={import.meta.env.BASE_URL + "rituel"} onClick={closeMenu}><span>07</span>Rituel</a>
          <a href={import.meta.env.BASE_URL + "minecraft"} onClick={closeMenu}><span>08</span>Skins Minecraft</a>
        </nav>
        <a className="header-signal" href="#faille" onClick={closeMenu}><Radio size={14} /> Ouvrir le signal</a>
      </header>

      <main>
        <section className="hero" id="top" aria-labelledby="hero-title">
          <img className="hero__image" src={ASSETS.hero} alt="Black dans une forêt nocturne devant une lune rouge" />
          <div className="hero__veil" />
          <div className="hero__grain" />
          <div className="container hero__content">
            <div className="hero__copy reveal-up">
              <div className="hero__sigil"><img src={ASSETS.symbol} alt="" /><span>BLACK / DREAM ENTITY</span></div>
              <p className="eyebrow"><span className="eyebrow__dot" /> Archive fictionnelle · Signal 001</p>
              <h1 id="hero-title">La nuit<br /><em>a un visage.</em></h1>
              <p className="hero__lede">Black ne hante pas les rêves. Il les collectionne. Et depuis qu’une faille s’est ouverte, il regarde enfin de l’autre côté.</p>
              <div className="hero__actions">
                <Button className="button button--primary" asChild><a href="#dossier">Entrer dans le dossier <ArrowDownRight size={16} /></a></Button>
                <a className="text-link" href="#galerie">Voir les preuves <ArrowUpRight size={15} /></a>
              </div>
            </div>
            <aside className="hero__note reveal-up reveal-up--delay">
              <div className="hero__note-top"><span>Case file</span><span>MLN / 001</span></div>
              <div className="hero__note-portrait"><img src={ASSETS.profile} alt="Portrait de Black" /></div>
              <div className="hero__note-bottom"><span>Black</span><span className="status"><i /> actif</span></div>
            </aside>
          </div>
          <div className="hero__footer container"><span>Equestria / monde réel</span><span className="scroll-cue"><i /> Défiler pour entrer</span><span>26.08.2026</span></div>
        </section>

        <section className="manifesto section-pad" id="dossier" aria-labelledby="dossier-title">
          <div className="archive-bar container"><span>Recovered file / 01</span><span>Do not reproduce</span></div>
          <div className="container manifesto__grid">
            <div className="section-label"><span>01</span><i /><span>Le dossier</span></div>
            <div className="manifesto__intro">
              <p className="kicker">My Little Nightmare</p>
              <h2 id="dossier-title">Une histoire qui<br /><em>refuse de dormir.</em></h2>
              <p className="body-copy">Dans Equestria, les Mane Six pensaient connaître la peur. Jusqu’à ce qu’une présence sans origine leur rende visite, nuit après nuit. Black, dieu des cauchemars, ne cherche pas à les détruire. Il cherche quelque chose de plus intime : la forme exacte de leur peur.</p>
              <p className="body-copy body-copy--muted">Cette archive rassemble une création originale, ses références et les fragments d’un monde qui se fissure.</p>
              <a className="arrow-link" href="#black">Rencontrer Black <ChevronRight size={16} /></a>
            </div>
            <div className="manifesto__quote"><span className="quote-mark">“</span><blockquote>Vous pensiez que les cauchemars étaient des histoires. Moi, je pensais que c’étaient des invitations.</blockquote><cite>— Black, dieu des cauchemars</cite></div>
          </div>
        </section>

        <section className="black-section section-pad" id="black" aria-labelledby="black-title">
          <div className="archive-bar archive-bar--dark container"><span>Subject file / 02</span><span>Eyes open / signal active</span></div>
          <div className="container black-section__grid">
            <div className="black-section__visual">
              <div className="image-frame image-frame--portrait"><img src={ASSETS.profile} alt="Portrait de Black, yeux rouges et crinière rayée" /></div>
              <span className="image-caption">Fig. 02 — Sujet observé / ne pas fixer les yeux</span>
            </div>
            <div className="black-section__copy">
              <div className="section-label"><span>02</span><i /><span>Sujet : Black</span></div>
              <p className="kicker">Le dieu qui écoute</p>
              <h2 id="black-title">Il connaît<br /><em>votre silence.</em></h2>
              <p className="body-copy">On le reconnaît à sa silhouette noire, sa crinière blanche striée et ce petit nœud rouge qui semble toujours trop calme. Ses yeux ne brillent pas pour éclairer la nuit : ils brillent parce qu’ils l’ont déjà traversée.</p>
              <dl className="spec-list">
                <div><dt>Nature</dt><dd>Entité onirique</dd></div>
                <div><dt>Territoire</dt><dd>Le sommeil · les écrans</dd></div>
                <div><dt>Signature</dt><dd>Un sabot dans la buée</dd></div>
              </dl>
              <div className="black-section__seal"><img src={ASSETS.symbol} alt="Sceau de Black" /><span>Marque d’archive<br /><strong>BRÛLURE CRAMOISIE</strong></span></div>
            </div>
          </div>
        </section>

        <section className="nightmares section-pad" id="cauchemars" aria-labelledby="nightmares-title">
          <div className="archive-bar archive-bar--dark container"><span>Dream log / 03</span><span>Six fears / one signature</span></div>
          <div className="container">
            <div className="section-heading"><div className="section-label"><span>03</span><i /><span>Les manifestations</span></div><p className="kicker">Six peurs · une seule signature</p><h2 id="nightmares-title">Chaque rêve<br /><em>laisse une trace.</em></h2></div>
            <div className="nightmares__lead">
              <figure className="feature-figure"><img src={ASSETS.library} alt="Bibliothèque vide dans un cauchemar" /><figcaption><span>Planche onirique 01</span><span>Les livres étaient vierges.</span></figcaption></figure>
              <div className="nightmares__intro"><span className="red-index">A / 06</span><h3>Le cauchemar est personnel.</h3><p>Black n’invente rien. Il prend ce qui existe déjà, le retourne lentement, puis le dépose au pied du lit.</p><a className="arrow-link" href="#galerie">Parcourir les fragments <ChevronRight size={16} /></a></div>
            </div>
            <div className="nightmares__list">{nightmares.map((item) => <a className="nightmare-row" href={`${import.meta.env.BASE_URL}cauchemar/${item.slug}`} key={item.number}><span className="nightmare-row__number">{item.number}</span><div><p className="nightmare-row__tag">{item.tag}</p><h3>{item.title}</h3></div><p className="nightmare-row__text">{item.text}</p><ArrowUpRight className="nightmare-row__arrow" size={19} /></a>)}</div>
            <figure className="feature-figure feature-figure--wide"><img src={ASSETS.realWorld} alt="Rue du monde réel envahie par la présence de Black" /><figcaption><span>Transmission 04 — monde réel</span><span>Il est déjà dans les reflets.</span></figcaption></figure>
          </div>
        </section>

        <section className="faille section-pad" id="faille" aria-labelledby="faille-title">
          <div className="container faille__grid">
            <div className="section-label"><span>04</span><i /><span>La faille</span></div>
            <div className="faille__copy"><p className="kicker">Alerte de transmission</p><h2 id="faille-title">Le monde réel<br /><em>n’est plus étanche.</em></h2><p className="body-copy">Une vidéo de huit secondes. Une porte blanche. Un reflet qui ne correspond pas à la pièce. Chaque fois qu’un humain regarde, la faille gagne un peu de terrain.</p><button className={`signal-button ${signalOn ? "signal-button--active" : ""}`} type="button" onClick={handleSignalToggle}><span className="signal-button__icon">{signalOn ? <Volume2 size={17} /> : <VolumeX size={17} />}</span><span>{signalOn ? "Signal ouvert — écoutez le silence" : "Activer le signal"}</span><ArrowUpRight size={16} /></button><p className="microcopy">{signalOn ? "Signal ouvert. Écoutez à votre rythme." : "Aucun audio n’est lancé automatiquement."}</p><div className="audio-player"><div className="audio-player__label"><span><Sparkles size={13} /> Preuve sonore récupérée</span><span>02:00 · D minor</span></div><audio ref={audioRef} controls preload="metadata" aria-label="Bande-son originale de My Little Nightmare"><source src={ASSETS.theme} type="audio/wav" />Votre navigateur ne prend pas en charge la lecture audio.</audio></div><div className="video-evidence"><div className="audio-player__label"><span><Radio size={13} /> Fragment vidéo récupéré · 08 sec</span><span>Transmission 001</span></div><video ref={videoRef} controls preload="metadata" playsInline poster="https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-signal-thumbnail_f73d2a73.png" aria-label="Signal vidéo de Black de huit secondes"><source src={ASSETS.signalVideo} type="video/mp4" />Votre navigateur ne prend pas en charge la lecture vidéo.</video><p>Fragment contaminé. Lecture manuelle requise.</p></div></div>
            <div className="faille__stamp"><img src={ASSETS.symbol} alt="" /><span>CASE STATUS</span><strong>{signalOn ? "OPEN" : "DORMANT"}</strong><small>Ne pas regarder seul<br />après 03:13</small></div>
          </div>
        </section>

        <section className="gallery section-pad" id="galerie" aria-labelledby="gallery-title">
          <div className="archive-bar archive-bar--dark container"><span>Evidence contact sheet / 05</span><span>Handle with care</span></div>
          <div className="container"><div className="section-heading section-heading--row"><div><div className="section-label"><span>05</span><i /><span>Preuves visuelles</span></div><p className="kicker">Galerie d’archive</p><h2 id="gallery-title">Les fragments<br /><em>restent ouverts.</em></h2></div><p className="section-heading__aside">Images issues du dossier de Black.<br />Cliquez pour agrandir.</p></div>
            <div className="gallery-grid">{gallery.map((item, index) => <button className={`gallery-card gallery-card--${index + 1}`} type="button" key={item.src} onClick={() => setActiveImage(item)}><span className="gallery-card__image"><img src={item.src} alt={item.alt} /></span><span className="gallery-card__meta"><span><small>{item.kicker}</small><strong>{item.label}</strong></span><ArrowUpRight size={17} /></span></button>)}</div>
          </div>
        </section>

        <section className="closing section-pad"><div className="archive-bar archive-bar--dark container"><span>End of file / 06</span><span>Signal unresolved</span></div><div className="container closing__inner"><img src={ASSETS.symbol} alt="Sceau de Black" /><p className="kicker">Fin de transmission</p><h2>Fermez les yeux.<br /><em>Il vous <a className="covert-letter-link" href={CHANNEL_URL} target="_blank" rel="noreferrer" aria-label="Ouvrir la chaîne YouTube de Black 72">a</a> déjà vu.</em></h2><a className="button button--outline" href="#top">Retourner au début <ArrowUpRight size={16} /></a><a className="covert-door-link" href={import.meta.env.BASE_URL + "horror"} aria-label="Ouvrir la porte secrète HORROR">Une porte sans nom</a></div></section>
      </main>

      <footer className="site-footer"><div className="container site-footer__inner"><div className="site-footer__brand"><span className="wordmark__mark"><img src={ASSETS.symbol} alt="" /></span><span><strong>MY LITTLE</strong><em>NIGHTMARE</em><small>Création originale · archive fictionnelle</small></span></div><p>Une histoire de Black, le dieu des cauchemars.</p><a className="covert-archive-link" href={import.meta.env.BASE_URL + "nightmare-archive"}>Accéder au dossier Nightmare <span aria-hidden="true">↗</span></a><span className="site-footer__code">MLN / END-OF-FILE</span></div></footer>

      {activeImage && <div className="lightbox" role="dialog" aria-modal="true" aria-label={`Agrandissement : ${activeImage.label}`} onClick={() => setActiveImage(null)}><div className="lightbox__panel" onClick={(event) => event.stopPropagation()}><button className="lightbox__close" type="button" onClick={() => setActiveImage(null)} aria-label="Fermer"><X size={20} /></button><img src={activeImage.src} alt={activeImage.alt} /><div className="lightbox__caption"><span>{activeImage.kicker}</span><strong>{activeImage.label}</strong></div></div></div>}
    </div>
  );
}
