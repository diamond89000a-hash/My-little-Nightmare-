// Direction artistique : dossier interdit du panthéon — portraits verticaux, ivoire d’archive, charbon profond et cramoisi réservé aux alertes.
import { ArrowLeft, ArrowUpRight, Eye, LockKeyhole, Radio } from "lucide-react";

const ASSETS = {
  symbol: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-symbol_9d3fb021.png",
  mnesara: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/secret-god-mnesara-light_66d801f4.png",
  veyr: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/secret-god-veyr-light_b8da381f.png",
  selenombre: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/secret-god-selenombre-light_24f9eee6.png",
  echolys: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/secret-god-echolys-light_310ef3a6.png",
  morbelle: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/secret-god-morbelle-light_5201f560.png",
  aubeFroide: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/secret-god-aube-froide-light_ad6d5c51.png",
};

type Deity = {
  name: string;
  role: string;
  domain: string;
  image: string;
  alt: string;
  description: string;
  symbol: string;
  relation: string;
};

const deities: Deity[] = [
  { name: "Mnésara", role: "Déesse des souvenirs oubliés", domain: "Mémoire / Effacement", image: ASSETS.mnesara, alt: "Mnésara, déesse grise aux yeux dorés dans une archive de souvenirs", description: "Elle veille sur les souvenirs que les rêves ont abandonnés. Sa clé brisée ouvre les portes des histoires que chacun croit avoir oubliées.", symbol: "Clé brisée", relation: "Elle connaît un fragment du passé de Black et refuse de le lui rendre." },
  { name: "Veyr", role: "Gardien des portes entre les mondes", domain: "Passages / Frontières", image: ASSETS.veyr, alt: "Veyr, gardien sombre devant une porte sans poignée", description: "Veyr surveille les seuils qui séparent le sommeil, les cauchemars et la réalité. Aucune porte ne s’ouvre sans qu’il en entende le verrou.", symbol: "Porte sans poignée", relation: "Il laisse Black voyager, mais garde toujours une issue fermée." },
  { name: "Sélénombre", role: "Déesse du sommeil profond", domain: "Sommeil / Silence", image: ASSETS.selenombre, alt: "Sélénombre, alicorne bleu nuit sous une lune sans étoiles", description: "Elle règne sur les nuits dont personne ne revient avec un souvenir clair. Son royaume est calme, trop calme pour être innocent.", symbol: "Croissant noir", relation: "Elle considère Black comme une perturbation de l’équilibre des songes." },
  { name: "Écholys", role: "Déesse des voix et des secrets", domain: "Voix / Résonance", image: ASSETS.echolys, alt: "Écholys, déesse ivoire entourée d’ondes et de murmures", description: "Écholys recueille les mots jamais prononcés. Elle peut faire résonner une confession dans le rêve de quelqu’un qui ne l’a jamais entendue.", symbol: "Bouche scellée", relation: "Elle répète parfois les paroles de Black avant même qu’il ne les dise." },
  { name: "Morbelle", role: "Reine des reflets et des illusions", domain: "Doubles / Apparences", image: ASSETS.morbelle, alt: "Morbelle, reine aux yeux différents devant un miroir fissuré", description: "Morbelle transforme chaque reflet en possibilité. Dans son royaume, personne ne sait quel visage est le premier et lequel attend derrière la vitre.", symbol: "Œil fendu", relation: "Elle admire Black, mais rêve de lui prendre la maîtrise des cauchemars." },
  { name: "Aube-Froide", role: "Déesse des faux espoirs", domain: "Lumière / Déception", image: ASSETS.aubeFroide, alt: "Aube-Froide, pégase dorée sous une lumière d’aube fissurée", description: "Elle offre une lumière parfaite aux rêveurs perdus. Mais son lever de soleil ne réchauffe rien : il révèle seulement que la sortie n’a jamais existé.", symbol: "Soleil fissuré", relation: "Elle est l’opposée de Black, mais leurs méthodes se ressemblent davantage qu’ils ne l’admettent." },
];

export default function Pantheon() {
  return (
    <div className="pantheon-page">
      <header className="pantheon-header">
        <a className="wordmark" href={import.meta.env.BASE_URL + "site"} aria-label="Retour au dossier principal de My Little Nightmare"><span className="wordmark__mark"><img src={ASSETS.symbol} alt="" /></span><span className="wordmark__text"><strong>MY LITTLE</strong><em>NIGHTMARE</em></span></a>
        <span className="pantheon-header__status"><LockKeyhole size={13} /> Dossier interdit / 07</span>
      </header>

      <main>
        <section className="pantheon-hero">
          <div className="pantheon-hero__veil" />
          <div className="container pantheon-hero__inner">
            <a className="back-link" href={import.meta.env.BASE_URL + "preuves"}><ArrowLeft size={15} /> Retour aux preuves</a>
            <div className="pantheon-hero__copy">
              <p className="kicker">Restricted archive / 07 · Accès non autorisé</p>
              <p className="pantheon-hero__eyebrow"><Radio size={13} /> Le panthéon sous la faille</p>
              <h1>Ils étaient là<br /><em>avant Black.</em></h1>
              <p className="pantheon-hero__lede">Six puissances veillent derrière les rêves. Leurs noms ont été retirés des archives publiques, mais leurs domaines continuent de toucher le monde réel.</p>
            </div>
            <aside className="pantheon-hero__seal"><img src={ASSETS.symbol} alt="" /><span>BLACK / EYES ONLY</span><strong>SEALED</strong><small>6 présences classées<br />1 lien avec Black</small></aside>
          </div>
          <div className="pantheon-hero__code">MLN / RESTRICTED PANTHEON / DO NOT DREAM</div>
        </section>

        <section className="pantheon-intro section-pad">
          <div className="container pantheon-intro__grid">
            <div className="section-label"><span>01</span><i /><span>Note de conservation</span></div>
            <article><p className="kicker">Document partiellement effacé</p><h2>Le cauchemar<br /><em>n’est pas seul.</em></h2><p className="body-copy">Black règne sur la peur, mais il ne règne pas sur tout. Autour de lui existent des dieux plus anciens, chacun attaché à une frontière fragile de l’esprit. Les portraits ci-dessous sont des fragments conceptuels reconstruits à partir des preuves retrouvées.</p><div className="pantheon-intro__warning"><Eye size={16} /><span>Ne prononcez pas leurs noms pendant votre sommeil.</span></div></article>
            <aside className="pantheon-intro__quote"><blockquote>« Chaque dieu garde une porte. Black garde ce qui passe sous la porte. »</blockquote><cite>— Note sans signature, marge du dossier 07</cite></aside>
          </div>
        </section>

        <section className="pantheon-grid-section section-pad" aria-labelledby="pantheon-title">
          <div className="container"><div className="archive-bar archive-bar--dark"><span>Restricted contact sheet / 07</span><span>Six entities indexed</span></div><div className="section-heading"><div className="section-label"><span>02</span><i /><span>Présences classées</span></div><p className="kicker">Portraits conceptuels · identités instables</p><h2 id="pantheon-title">Les gardiens<br /><em>de l’impossible.</em></h2></div><div className="pantheon-grid">{deities.map((deity, index) => <article className={`pantheon-card pantheon-card--${index + 1}`} key={deity.name}><div className="pantheon-card__image"><img src={deity.image} alt={deity.alt} /><span className="pantheon-card__scan">GOD / 0{index + 1}</span></div><div className="pantheon-card__body"><p className="kicker">{deity.domain}</p><h3>{deity.name}</h3><strong>{deity.role}</strong><p>{deity.description}</p><div className="pantheon-card__detail"><span>{deity.symbol}</span><small>{deity.relation}</small></div></div></article>)}</div></div>
        </section>

        <section className="pantheon-closure section-pad"><div className="container pantheon-closure__inner"><img src={ASSETS.symbol} alt="Sceau de Black" /><p className="kicker">Fin du dossier interdit</p><h2>Tu connais leurs noms.<br /><em>Ils connaissent le tien.</em></h2><p>Refermez cette page avant que la septième présence ne soit ajoutée à l’inventaire.</p><a className="button button--outline" href={import.meta.env.BASE_URL + "site"}>Quitter le dossier <ArrowUpRight size={16} /></a></div></section>
      </main>

      <footer className="site-footer"><div className="container site-footer__inner"><span>MY LITTLE NIGHTMARE / ARCHIVE FICTIONNELLE</span><span className="site-footer__code">PANTHEON / 07</span></div></footer>
    </div>
  );
}
