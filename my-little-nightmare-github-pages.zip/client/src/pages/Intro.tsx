// Direction artistique : cabinet de curiosités nocturne — seuil éditorial, asymétrique et silencieux avant l’archive principale.
import { ArrowRight, Eye, Radio } from "lucide-react";

const ASSETS = {
  hero: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/my-little-nightmare-hero_670b7a46.png",
  symbol: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-symbol_9d3fb021.png",
  profile: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-profile_0707698f.png",
};

export default function Intro() {
  return (
    <main className="intro-page">
      <img className="intro-page__background" src={ASSETS.hero} alt="Forêt nocturne et lune rouge derrière Black" />
      <div className="intro-page__veil" />
      <div className="intro-page__grain" aria-hidden="true" />

      <header className="intro-header">
        <a className="wordmark" href={import.meta.env.BASE_URL + ""} aria-label="My Little Nightmare, page d’introduction">
          <span className="wordmark__mark"><img src={ASSETS.symbol} alt="" /></span>
          <span className="wordmark__text"><strong>MY LITTLE</strong><em>NIGHTMARE</em></span>
        </a>
        <span className="intro-header__status"><Radio size={13} /> Signal dormant</span>
      </header>

      <div className="intro-page__content container">
        <section className="intro-page__copy" aria-labelledby="intro-title">
          <p className="intro-page__eyebrow"><span className="intro-page__dot" /> Archive fictionnelle · Accès préalable</p>
          <p className="intro-page__index">DOSSIER MLN / 000</p>
          <h1 id="intro-title">Avant le rêve,<br /><em>il y a le seuil.</em></h1>
          <p className="intro-page__lede">Quelqu’un a laissé une porte ouverte entre les songes et les archives. Si vous êtes arrivé jusqu’ici, Black sait déjà que vous êtes là.</p>
          <div className="intro-page__actions">
            <a className="button button--primary intro-page__enter" href={import.meta.env.BASE_URL + "site"}>
              Ouvrir le dossier <ArrowRight size={16} />
            </a>
            <span className="intro-page__hint"><Eye size={14} /> Lecture déconseillée après minuit</span>
          </div>
        </section>

        <aside className="intro-file" aria-label="Fiche de transmission">
          <div className="intro-file__top"><span>TRANSMISSION / 00</span><span>NON CLASSÉE</span></div>
          <div className="intro-file__portrait"><img src={ASSETS.profile} alt="Portrait de Black aux yeux rouges" /></div>
          <div className="intro-file__caption"><strong>BLACK</strong><span><i /> OBSERVE</span></div>
          <div className="intro-file__line" />
          <p>« Ne vous souvenez-vous pas de m’avoir déjà rencontré ? »</p>
        </aside>
      </div>

      <footer className="intro-footer container">
        <span>Équestria / Monde réel</span>
        <span>Entrée sécurisée par aucun rêve</span>
        <span>Archive 00:00</span>
      </footer>
    </main>
  );
}
