// Direction artistique : chaque page est une fiche de dossier retrouvée, entre ivoire d’archive, charbon bleuté et cramoisi réservé aux alertes de Black.
import { ArrowLeft, ArrowUpRight, Eye, Radio } from "lucide-react";
import { useRoute } from "wouter";
import { useEffect } from "react";

const ASSETS = {
  library: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/nightmare-library_abafbcba.png",
  realWorld: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/real-world-invasion_d9870c55.png",
  joyful: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-joyful_95143773.png",
  afraid: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-afraid_34657315.png",
  sad: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-sad_1dede4f5.png",
  crossover: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/crossover_df6cfff7.png",
  symbol: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-symbol_9d3fb021.png",
  twilightVideo: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/twilight-nightmare-inshot_8fb62d18.mp4",
  pinkieVideo: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/pinkie-nightmare-inshot_43010fa0.mp4",
  rainbowVideo: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/nightmare-rainbow-dash-evidence_4fc1ca63.mp4",
  rarityVideo: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/nightmare-rarity-evidence_2431a8b7.mp4",
  fluttershyVideo: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/nightmare-fluttershy-evidence_0529f3d7.mp4",
  applejackVideo: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/nightmare-applejack-evidence_fa2948db.mp4",
};

type NightmareEntry = {
  slug: string;
  number: string;
  letter: string;
  character: string;
  title: string;
  subtitle: string;
  reference: string;
  image: string;
  imageAlt: string;
  fear: string;
  story: string[];
  quote: string;
  trace: string;
};

type VideoEvidence = {
  title: string;
  accent: string;
  character: string;
  description: string;
  fileLabel: string;
  warning: string;
  code: string;
  source: string;
  ariaLabel: string;
};

const entries: NightmareEntry[] = [
  { slug: "twilight", number: "01", letter: "H", character: "Twilight Sparkle", title: "Les pages vierges", subtitle: "Quand la connaissance disparaît, que reste-t-il de soi ?", reference: "Peur intime · L’effacement", image: ASSETS.library, imageAlt: "Bibliothèque vide dans une lumière froide", fear: "Oublier tout ce qu’elle sait.", story: ["Twilight se réveilla au milieu de sa bibliothèque. Les rayonnages étaient toujours là, mais les titres avaient disparu.", "Elle ouvrit un livre, puis un second. Chaque page était parfaitement blanche. Même son propre journal ne contenait plus une seule ligne.", "Au fond de la salle, une page se tourna toute seule. Elle portait un seul mot : Black."], quote: "Une histoire sans mots est encore un rêve qui attend son lecteur.", trace: "Encre absente · 03:13" },
  { slug: "pinkie", number: "02", letter: "O", character: "Pinkie Pie", title: "Le sucre rouge", subtitle: "La fête continue quand personne ne devrait plus sourire.", reference: "Clin d’œil · Cupcakes", image: ASSETS.joyful, imageAlt: "Black souriant dans une image lumineuse contaminée", fear: "Découvrir ce qui se cache derrière la fête.", story: ["Pinkie prépara une fournée de cupcakes à la fraise, en chantonnant comme toujours. La cuisine sentait le sucre chaud et le beurre.", "Quand le four sonna, les gâteaux avaient changé. Leur glaçage était sombre, leur parfum métallique. Dans le sous-sol, les voix de ses amies l’appelaient derrière une porte verrouillée.", "Sur le mur, écrit avec une pâte rouge, une phrase l’attendait : Souris pour Black."], quote: "Le rire est plus beau juste avant qu’il ne devienne un cri.", trace: "Recette modifiée · 06 ingrédients" },
  { slug: "rainbow", number: "03", letter: "R", character: "Rainbow Dash", title: "Le ciel immobile", subtitle: "Ses ailes battent, mais le monde refuse de la laisser décoller.", reference: "Peur intime · L’impuissance", image: ASSETS.afraid, imageAlt: "Silhouette effrayée dans une forêt obscure", fear: "Ne plus pouvoir voler.", story: ["Rainbow Dash s’élança depuis un nuage. Ses ailes frappèrent l’air avec force, mais son corps resta suspendu au même endroit.", "Elle recommença. Plus vite. Plus fort. Le ciel demeurait parfaitement immobile, comme une image arrêtée.", "Alors elle aperçut, sous les nuages, deux yeux rouges qui montaient vers elle. Pour la première fois, quelque chose volait plus haut qu’elle."], quote: "Même le ciel a un plafond quand Black ferme les yeux.", trace: "Altitude impossible · 0 mètre" },
  { slug: "rarity", number: "04", letter: "R", character: "Rarity", title: "La dernière collection", subtitle: "Chaque création est parfaite. Personne ne la regarde.", reference: "Peur intime · Le rejet", image: ASSETS.sad, imageAlt: "Portrait mélancolique sous la pluie", fear: "Créer sans jamais être reconnue.", story: ["Rarity arrangea ses tissus les plus précieux sous les projecteurs. Les robes étaient magnifiques, plus élégantes que tout ce qu’elle avait créé.", "Pourtant, la boutique resta vide. Les vitrines reflétaient ses créations, mais jamais son visage.", "Au matin, une étiquette était attachée à chaque robe : Inutile. Dans le miroir, son reflet portait une crinière noire et blanche."], quote: "La beauté n’a pas besoin d’applaudissements. Mais Rarity, elle, en avait besoin.", trace: "Collection abandonnée · 12 pièces" },
  { slug: "fluttershy", number: "05", letter: "O", character: "Fluttershy", title: "La cabane", subtitle: "Dans la forêt silencieuse, quelqu’un prend soin des animaux à sa place.", reference: "Clin d’œil · shed.mov", image: ASSETS.crossover, imageAlt: "Créatures silhouettes réunies dans une scène de cauchemar", fear: "Ne plus retrouver les animaux qu’elle protège.", story: ["Fluttershy marcha longtemps sans entendre un seul chant d’oiseau. La forêt était vide, jusqu’à ce qu’une trace sombre apparaisse entre les arbres.", "Elle la suivit jusqu’à une cabane dont la porte était entrouverte. À l’intérieur, tous les animaux la regardaient en silence.", "Au milieu de la pièce, une autre Fluttershy leva lentement la tête. Dans ses sabots, elle tenait une scie dont le moteur venait de s’arrêter."], quote: "La douceur devient terrifiante quand elle n’a plus personne à protéger.", trace: "Cabane retrouvée · porte ouverte" },
  { slug: "applejack", number: "06", letter: "R", character: "Applejack", title: "La récolte noire", subtitle: "Quand la colère prend racine, même la ferme ne reconnaît plus sa gardienne.", reference: "Clin d’œil · Bats! · La rage", image: ASSETS.realWorld, imageAlt: "Rue envahie par des lumières rouges surnaturelles", fear: "Perdre le contrôle et blesser les siens.", story: ["Applejack chassa les chauves-souris qui dévoraient ses fruits, comme dans le souvenir déformé de Bats!. Elles revinrent plus nombreuses, tournant autour de la grange comme un essaim.", "La colère monta en elle jusqu’à couvrir tous les autres sons. Elle ne vit plus ses amies comme des alliées, mais comme des silhouettes à repousser.", "Quand Celestia et Luna arrivèrent, la ferme était silencieuse. Dans la terre, six ombres formaient un cercle autour d’un symbole rouge."], quote: "La rage ne frappe jamais seule. Elle apporte toujours un témoin.", trace: "Récolte perdue · lune décroissante" },
];

export default function Nightmare() {
  const [, params] = useRoute("/cauchemar/:slug");
  const entry = entries.find((item) => item.slug === params?.slug) ?? entries[0];

  useEffect(() => {
    window.localStorage.setItem(`mln-nightmare-found-${entry.slug}`, entry.letter);
  }, [entry.letter, entry.slug]);

  const videoEvidence: VideoEvidence | null = entry.slug === "twilight" ? {
    title: "La bibliothèque",
    accent: "enregistre encore.",
    character: "Twilight Sparkle",
    description: "Un fragment vidéo a été retrouvé dans le dossier de Twilight Sparkle. Les images montrent ce qui reste lorsque les histoires disparaissent : une pièce familière, des pages muettes et une présence hors champ.",
    fileLabel: "TWILIGHT / BLANK BOOKS / MP4",
    warning: "Ne pas relancer la lecture après 03:13.",
    code: "TWILIGHT / 01",
    source: ASSETS.twilightVideo,
    ariaLabel: "Vidéo du cauchemar de Twilight Sparkle",
  } : entry.slug === "pinkie" ? {
    title: "La fête",
    accent: "ne s’arrête pas.",
    character: "Pinkie Pie",
    description: "Un fragment vidéo a été retrouvé près du four de Pinkie Pie. Les images montrent une cuisine familière, des gâteaux devenus étranges et une porte qui semble attendre qu’on l’ouvre.",
    fileLabel: "PINKIE / STRAWBERRY CUPCAKES / MP4",
    warning: "Ne pas relancer la lecture sans lumière.",
    code: "PINKIE / 02",
    source: ASSETS.pinkieVideo,
    ariaLabel: "Vidéo du cauchemar de Pinkie Pie",
  } : entry.slug === "rainbow" ? {
    title: "Le ciel immobile",
    accent: "refuse de la porter.",
    character: "Rainbow Dash",
    description: "Un fragment vidéo a été récupéré au-dessus d’une zone nuageuse sans mouvement. Rainbow Dash tente de prendre son envol, mais ses ailes battent dans un ciel qui semble avoir cessé d’exister.",
    fileLabel: "RAINBOW / FROZEN SKY / MP4",
    warning: "Ne pas regarder le ciel après la dernière image.",
    code: "RAINBOW / 03",
    source: ASSETS.rainbowVideo,
    ariaLabel: "Vidéo du cauchemar de Rainbow Dash",
  } : entry.slug === "rarity" ? {
    title: "La dernière collection",
    accent: "n’intéresse personne.",
    character: "Rarity",
    description: "Un fragment vidéo a été retrouvé dans la boutique de Rarity après la fermeture. Les créations sont intactes, les projecteurs sont allumés, mais aucun regard ne vient plus les admirer.",
    fileLabel: "RARITY / LAST COLLECTION / MP4",
    warning: "Ne pas rester face aux vitrines après la fin de la bande.",
    code: "RARITY / 04",
    source: ASSETS.rarityVideo,
    ariaLabel: "Vidéo du cauchemar de Rarity",
  } : entry.slug === "fluttershy" ? {
    title: "La cabane",
    accent: "n’est plus vide.",
    character: "Fluttershy",
    description: "Un fragment vidéo a été retrouvé devant la cabane de Fluttershy. La forêt est silencieuse, les animaux ont disparu et quelque chose semble attendre derrière la porte entrouverte.",
    fileLabel: "FLUTTERSHY / SHED / MP4",
    warning: "Ne pas ouvrir la porte après le dernier arrêt sur image.",
    code: "FLUTTERSHY / 05",
    source: ASSETS.fluttershyVideo,
    ariaLabel: "Vidéo du cauchemar de Fluttershy",
  } : entry.slug === "applejack" ? {
    title: "La récolte noire",
    accent: "la rage revient.",
    character: "Applejack",
    description: "Un fragment vidéo a été retrouvé près de la grange après l’invasion des chauves-souris. La ferme est silencieuse, les récoltes sont noircies et la colère d’Applejack semble encore circuler dans le verger.",
    fileLabel: "APPLEJACK / BATS / MP4",
    warning: "Ne pas écouter les battements après l’extinction de la lune.",
    code: "APPLEJACK / 06",
    source: ASSETS.applejackVideo,
    ariaLabel: "Vidéo du cauchemar d’Applejack",
  } : null;

  return (
    <div className="nightmare-page">
      <header className="nightmare-header">
        <a className="wordmark" href={import.meta.env.BASE_URL + "site"} aria-label="Retour à My Little Nightmare"><span className="wordmark__mark"><img src={ASSETS.symbol} alt="" /></span><span className="wordmark__text"><strong>MY LITTLE</strong><em>NIGHTMARE</em></span></a>
        <span className="nightmare-header__signal"><Radio size={13} /> Dossier individuel / {entry.number}</span>
      </header>
      <main>
        <section className="nightmare-hero">
          <div className="nightmare-hero__image"><img src={entry.image} alt={entry.imageAlt} /></div>
          <div className="nightmare-hero__veil" />
          <div className="container nightmare-hero__content">
            <a className="back-link" href={import.meta.env.BASE_URL + "site#cauchemars"}><ArrowLeft size={15} /> Retour aux manifestations</a>
            <p className="kicker">Dream log / {entry.number} · Signal contaminé</p>
            <p className="nightmare-hero__character">{entry.character}</p>
            <h1>{entry.title}<br /><em>{entry.subtitle}</em></h1>
            <div className="nightmare-hero__meta"><span>Peur identifiée</span><strong>{entry.fear}</strong></div>
            <div className="nightmare-letter" aria-label={`Fragment du mot secret HORROR : lettre ${entry.letter}`}><span>Fragment / HORROR</span><strong>{entry.letter}</strong></div>
          </div>
          <span className="nightmare-hero__code">MLN / NIGHTMARE / {entry.number}</span>
        </section>
        <section className="nightmare-reading section-pad">
          <div className="container nightmare-reading__grid">
            <div className="section-label"><span>{entry.number}</span><i /><span>Lecture du dossier</span></div>
            <article className="nightmare-story"><p className="kicker">{entry.slug === "fluttershy" ? <>Clin d’œil · <a className="nightmare-story__link" href="https://youtu.be/cH-yA8U2XgI?is=KAX1DvdVHyOdtvIL" target="_blank" rel="noreferrer" aria-label="Voir la vidéo de référence shed.mov sur YouTube">shed.mov</a></> : entry.slug === "applejack" ? <>Clin d’œil · <a className="nightmare-story__link" href="https://youtu.be/Qsp1CTl86w8?feature=shared" target="_blank" rel="noreferrer" aria-label="Voir l’épisode Bats! sur YouTube">Bats!</a> · La rage</> : entry.reference}</p><h2>Ce qu’elle<br /><em>a vu.</em></h2>{entry.story.map((paragraph) => <p className="body-copy" key={paragraph}>{entry.slug === "pinkie" && paragraph.includes("cupcakes") ? <>{paragraph.split("cupcakes")[0]}<a className="nightmare-story__link" href="https://youtu.be/d4Nxs3ngyqI?is=bRdYxAE1oHMR2UXj" target="_blank" rel="noreferrer" aria-label="Voir la vidéo de référence Cupcakes sur YouTube">cupcakes</a>{paragraph.split("cupcakes")[1]}</> : paragraph}</p>)}<div className="nightmare-trace"><span>Trace enregistrée</span><strong>{entry.trace}</strong></div></article>
            <aside className="nightmare-quote"><img src={ASSETS.symbol} alt="" /><blockquote>“{entry.quote}”</blockquote><cite>— Extrait de l’archive Black</cite></aside>
          </div>
        </section>
        {videoEvidence && <section className="nightmare-video-evidence section-pad" aria-labelledby="nightmare-video-title">
          <div className="container nightmare-video__grid">
            <div className="section-label"><span>03</span><i /><span>Preuve vidéo</span></div>
            <article className="nightmare-video__copy"><p className="kicker">Recovered video / {videoEvidence.code} · Lecture manuelle</p><h2 id="nightmare-video-title">{videoEvidence.title}<br /><em>{videoEvidence.accent}</em></h2><p className="body-copy">{videoEvidence.description}</p><div className="nightmare-video__trace"><span>Fichier récupéré</span><strong>{videoEvidence.fileLabel}</strong><small>{videoEvidence.warning}</small></div></article>
            <div className="nightmare-video-frame"><div className="nightmare-video-frame__top"><span><Eye size={13} /> Appareil vidéo récupéré</span><span>{videoEvidence.code}</span></div><video controls preload="metadata" playsInline aria-label={videoEvidence.ariaLabel}><source src={videoEvidence.source} type="video/mp4" />Votre navigateur ne prend pas en charge la lecture vidéo.</video><div className="nightmare-video-frame__bottom"><span>SIGNAL / MANUEL</span><span>Lecture non automatique</span></div></div>
          </div>
        </section>}
        <section className="nightmare-next">
          <div className="container"><div className="nightmare-next__top"><span className="section-label"><span>Archive</span><i /><span>Continuer</span></span><span className="nightmare-next__status"><Eye size={14} /> Ne pas lire seul</span></div><div className="nightmare-next__links"><a href={import.meta.env.BASE_URL + "site#cauchemars"} className="button button--outline"><ArrowLeft size={15} /> Voir les six cauchemars</a><a href={import.meta.env.BASE_URL + "site"} className="arrow-link">Retour au dossier principal <ArrowUpRight size={16} /></a></div></div>
        </section>
      </main>
      <footer className="site-footer"><div className="container site-footer__inner"><span>MY LITTLE NIGHTMARE / ARCHIVE FICTIONNELLE</span><span className="site-footer__code">SIGNAL / {entry.number}</span></div></footer>
    </div>
  );
}
