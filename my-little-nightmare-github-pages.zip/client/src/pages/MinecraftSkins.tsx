import { ArrowDownToLine, ArrowLeft, Box, Gamepad2, Shield } from "lucide-react";

const skins = [
  {
    title: "Black · Costard",
    code: "SKIN / 01",
    description: "La tenue officielle de Black : costume noir, chemise blanche et nœud papillon rouge.",
    image: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/1000017279_34cb3275.png",
    file: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/1000017279_34cb3275.png",
    filename: "black-costard.png",
    accent: "classique",
  },
  {
    title: "Black · Cauchemar",
    code: "SKIN / 02",
    description: "Une variante plus inquiétante avec des yeux rouges renforcés pour le Royaume des Cauchemars.",
    image: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/1000019417_6bb9583e.png",
    file: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/1000019417_6bb9583e.png",
    filename: "black-cauchemar.png",
    accent: "contaminé",
  },
];

export default function MinecraftSkins() {
  return (
    <div className="minecraft-page">
      <header className="minecraft-header">
        <a className="wordmark" href={import.meta.env.BASE_URL + "site"} aria-label="Retour à My Little Nightmare">
          <span className="wordmark__mark"><img src="https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-symbol_9d3fb021.png" alt="" /></span>
          <span className="wordmark__text"><strong>MY LITTLE</strong><em>NIGHTMARE</em></span>
        </a>
        <span className="minecraft-header__status"><Gamepad2 size={13} /> Minecraft Bedrock / archive 10</span>
      </header>

      <main>
        <section className="minecraft-hero">
          <div className="container minecraft-hero__inner">
            <a className="back-link" href={import.meta.env.BASE_URL + "site"}><ArrowLeft size={15} /> Retour à l’archive</a>
            <div className="minecraft-hero__copy">
              <p className="kicker">Royaume des Cauchemars · Bedrock</p>
              <p className="minecraft-hero__eyebrow"><Box size={13} /> Fichiers de personnage</p>
              <h1>Black entre<br /><em>dans le monde cubique.</em></h1>
              <p className="minecraft-hero__lede">Télécharge les skins officiels de Black pour incarner le dieu des cauchemars dans Minecraft Bedrock.</p>
            </div>
            <div className="minecraft-hero__stamp"><Shield size={22} /><span>FORMAT VALIDÉ</span><strong>64 × 64</strong><small>PNG · Bedrock<br />Import manuel</small></div>
          </div>
          <div className="minecraft-hero__code">MLN / MINECRAFT / CHARACTER FILES</div>
        </section>

        <section className="minecraft-downloads section-pad" aria-labelledby="minecraft-title">
          <div className="container">
            <div className="archive-bar archive-bar--dark"><span>Character skins / 10</span><span>2 fichiers disponibles</span></div>
            <div className="minecraft-heading">
              <div className="section-label"><span>10</span><i /><span>Les apparences</span></div>
              <p className="kicker">Téléchargements officiels</p>
              <h2 id="minecraft-title">Choisis ton<br /><em>niveau de cauchemar.</em></h2>
              <p className="body-copy">Les deux fichiers sont des skins PNG au format 64 × 64. Télécharge une apparence, puis importe-la depuis le menu « Dressing » de Minecraft Bedrock.</p>
            </div>
            <div className="minecraft-skin-grid">
              {skins.map((skin) => (
                <article className={`minecraft-skin-card minecraft-skin-card--${skin.accent}`} key={skin.file}>
                  <div className="minecraft-skin-card__top"><span>{skin.code}</span><span>PNG / 64×64</span></div>
                  <div className="minecraft-skin-card__preview"><img src={skin.image} alt={`Aperçu du skin Minecraft ${skin.title}`} /><span className="minecraft-skin-card__scan"><Gamepad2 size={13} /> READY TO IMPORT</span></div>
                  <div className="minecraft-skin-card__body"><p className="kicker">{skin.accent === "contaminé" ? "Royaume des Cauchemars" : "Tenue de cérémonie"}</p><h3>{skin.title}</h3><p>{skin.description}</p><a className="button button--primary minecraft-skin-card__download" href={skin.file} download={skin.filename}><ArrowDownToLine size={15} /> Télécharger le skin</a></div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="minecraft-guide section-pad">
          <div className="container minecraft-guide__inner">
            <div className="minecraft-guide__icon"><Gamepad2 size={21} /></div>
            <div><p className="kicker">Import rapide</p><h2>Donne-lui une place<br /><em>dans ton monde.</em></h2><p>Sur Bedrock, ouvre le Dressing, choisis « Modifier le personnage », puis l’icône de skin classique. Sélectionne le PNG téléchargé et confirme le modèle classique avec bras de 4 pixels.</p></div>
          </div>
        </section>
      </main>

      <footer className="site-footer"><div className="container site-footer__inner"><span>MY LITTLE NIGHTMARE / ARCHIVE FICTIONNELLE</span><a href={import.meta.env.BASE_URL + "site"}>Retour au site</a></div></footer>
    </div>
  );
}
