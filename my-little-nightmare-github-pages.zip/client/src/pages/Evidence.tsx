// Direction artistique : planche de preuves d’un dossier paranormal — matière sombre, cadres techniques et cramoisi réservé aux contaminations.
import { ArrowLeft, ArrowUpRight, Camera, Eye, Headphones, Radio, ScanLine, X } from "lucide-react";
import { useEffect, useState } from "react";

const ASSETS = {
  symbol: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-symbol_9d3fb021.png",
  origin: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-origin_657f0123.png",
  profile: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-profile_0707698f.png",
  afraid: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-afraid_34657315.png",
  sad: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-sad_1dede4f5.png",
  joyful: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-joyful_95143773.png",
  laughing: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-laughing.png",
  crossover: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/crossover_df6cfff7.png",
  signalThumbnail: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-signal-thumbnail_f73d2a73.png",
  signalVideo: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-signal-8s_7d77a482.mp4",
  theme: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/my-little-nightmare-theme_c7879d5b.wav",
  diary: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-audio-diary_b8b94532.wav",
};

type VisualEvidence = {
  id: string;
  src: string;
  label: string;
  code: string;
  note: string;
  alt: string;
};

const visualEvidence: VisualEvidence[] = [
  { id: "origin", src: ASSETS.origin, label: "L’apparition", code: "IMG / 001", note: "Premier cercle de présence", alt: "Black au centre d’un cercle de cauchemars" },
  { id: "profile", src: ASSETS.profile, label: "Le visage", code: "IMG / 002", note: "Portrait signalé · yeux ouverts", alt: "Portrait rapproché de Black aux yeux rouges" },
  { id: "afraid", src: ASSETS.afraid, label: "La peur retourne", code: "IMG / 003", note: "Réaction non classée", alt: "Black effrayé dans une forêt face à une silhouette" },
  { id: "sad", src: ASSETS.sad, label: "Après le rêve", code: "IMG / 004", note: "Trace émotionnelle", alt: "Black triste sous la pluie" },
  { id: "joyful", src: ASSETS.joyful, label: "Le masque tombe", code: "IMG / 005", note: "Preuve contaminée", alt: "Black joyeux dans un champ fleuri" },
  { id: "laughing", src: ASSETS.laughing, label: "Le rire", code: "IMG / 006", note: "Fréquence instable", alt: "Black en train de rire" },
  { id: "crossover", src: ASSETS.crossover, label: "Le conseil noir", code: "IMG / 007", note: "Présences multiples", alt: "Black entouré de créatures de creepypasta" },
];

export default function Evidence() {
  const [activeEvidence, setActiveEvidence] = useState<VisualEvidence | null>(null);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setActiveEvidence(null);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  return (
    <div className="evidence-page">
      <header className="evidence-header">
        <a className="wordmark" href={import.meta.env.BASE_URL + "site"} aria-label="Retour au dossier principal de My Little Nightmare">
          <span className="wordmark__mark"><img src={ASSETS.symbol} alt="" /></span>
          <span className="wordmark__text"><strong>MY LITTLE</strong><em>NIGHTMARE</em></span>
        </a>
        <span className="evidence-header__status"><Radio size={13} /> Preuves sous scellé</span>
      </header>

      <main>
        <section className="evidence-hero">
          <div className="container evidence-hero__inner">
            <a className="back-link" href={import.meta.env.BASE_URL + "site"}><ArrowLeft size={15} /> Retour au dossier principal</a>
            <div className="evidence-hero__copy">
              <p className="kicker">Evidence room / 05 · Accès contrôlé</p>
              <p className="evidence-hero__eyebrow">Les preuves</p>
              <h1>Ce qu’il a<br /><em>laissé derrière lui.</em></h1>
              <p className="evidence-hero__lede">Images, fréquences et fragments récupérés après le passage de Black. Certaines preuves ont été classées. Aucune n’a été déclarée sûre.</p>
            </div>
            <aside className="evidence-hero__stamp" aria-label="Statut du dossier">
              <img src={ASSETS.symbol} alt="" />
              <span>CASE FILE / MLN-05</span>
              <strong>OPEN</strong>
              <small>7 images · 2 signaux<br />Dernière lecture : 03:13</small>
            </aside>
          </div>
          <div className="evidence-hero__code">DO NOT REPRODUCE / CONTACT SHEET 05</div>
        </section>

        <section className="evidence-intro section-pad">
          <div className="container evidence-intro__grid">
            <div className="section-label"><span>01</span><i /><span>État des preuves</span></div>
            <article>
              <p className="kicker">Inventaire partiel · lecture manuelle</p>
              <h2>Les fragments<br /><em>ne mentent pas.</em></h2>
              <p className="body-copy">Chaque image a été retrouvée dans un lieu différent. Pourtant, le même détail revient : un regard, une fissure, une présence qui semble attendre derrière la scène.</p>
              <div className="evidence-metrics"><div><strong>07</strong><span>Images classées</span></div><div><strong>02</strong><span>Signaux audio</span></div><div><strong>01</strong><span>Présence confirmée</span></div></div>
            </article>
            <aside className="evidence-intro__quote"><ScanLine size={19} /><blockquote>« Une preuve ne disparaît pas. Elle apprend seulement à se cacher. »</blockquote><cite>— Annotation attribuée à Black</cite></aside>
          </div>
        </section>

        <section className="evidence-gallery section-pad" aria-labelledby="evidence-gallery-title">
          <div className="archive-bar archive-bar--dark container"><span>Visual contact sheet / 05</span><span>Handle with care</span></div>
          <div className="container">
            <div className="section-heading section-heading--row"><div><div className="section-label"><span>02</span><i /><span>Fragments visuels</span></div><p className="kicker">Images récupérées · traitement contaminé</p><h2 id="evidence-gallery-title">Regarder, c’est<br /><em>laisser une trace.</em></h2></div><p className="section-heading__aside">Cliquez sur une preuve<br />pour l’examiner.</p></div>
            <div className="evidence-grid">
              {visualEvidence.map((item, index) => (
                <button className={`evidence-card evidence-card--${(index % 5) + 1} ${item.id === "joyful" ? "evidence-card--anomaly" : ""}`} type="button" key={item.id} onClick={() => setActiveEvidence(item)} aria-label={`Examiner la preuve ${item.label}`}>
                  <span className="evidence-card__image"><img src={item.src} alt={item.alt} /><span className="evidence-card__scan"><Camera size={13} /> {item.code}</span></span>
                  <span className="evidence-card__meta"><span><small>{item.note}</small><strong>{item.label}</strong></span><ArrowUpRight size={16} /></span>
                </button>
              ))}
            </div>
          </div>
        </section>

        <section className="evidence-transmissions section-pad" aria-labelledby="transmissions-title">
          <div className="container">
            <div className="section-label"><span>03</span><i /><span>Transmissions récupérées</span></div>
            <div className="evidence-transmissions__heading"><div><p className="kicker">Ne pas écouter seul</p><h2 id="transmissions-title">Les preuves<br /><em>parlent encore.</em></h2></div><p className="body-copy">Les lecteurs restent manuels. Aucun signal ne doit s’ouvrir sans votre consentement.</p></div>
            <div className="transmission-grid">
              <article className="transmission-card transmission-card--audio">
                <div className="transmission-card__top"><span><Headphones size={14} /> APPAREIL AUDIO / 001</span><span>01:29 · WAV</span></div>
                <div className="transmission-card__body"><div className="transmission-card__icon"><Radio size={24} /></div><div><h3>Journal de Black</h3><p>Une confession enregistrée entre deux rêves. La voix n’a pas été identifiée.</p></div></div>
                <audio controls preload="metadata" aria-label="Journal audio de Black"><source src={ASSETS.diary} type="audio/wav" />Votre navigateur ne prend pas en charge la lecture audio.</audio>
                <div className="transmission-card__foot"><span>VOICE TRACE / CONFIRMÉE</span><span>Appareil contrôlé</span></div>
              </article>
              <article className="transmission-card transmission-card--video">
                <div className="transmission-card__top"><span><Eye size={14} /> APPAREIL VIDÉO / 001</span><span>00:08 · MP4</span></div>
                <div className="transmission-card__body"><div className="transmission-card__icon"><Eye size={24} /></div><div><h3>La porte blanche</h3><p>Un reflet ne correspond pas à la pièce. Le signal s’arrête avant l’explication.</p></div></div>
                <video controls preload="metadata" playsInline poster={ASSETS.signalThumbnail} aria-label="Signal vidéo de Black"><source src={ASSETS.signalVideo} type="video/mp4" />Votre navigateur ne prend pas en charge la lecture vidéo.</video>
                <div className="transmission-card__foot"><span>SIGNAL / CONTAMINÉ</span><span>Appareil contrôlé</span></div>
              </article>
            </div>
          </div>
        </section>

        <section className="evidence-closure section-pad">
          <div className="container evidence-closure__inner"><img src={ASSETS.symbol} alt="Sceau de Black" /><p className="kicker">Fin de l’inventaire</p><h2>Vous avez vu<br /><em>les preuves.</em></h2><p>La question n’est plus de savoir si Black existe. La question est de savoir pourquoi il vous a laissé regarder.</p><a className="button button--outline" href={import.meta.env.BASE_URL + "site"}>Fermer la salle des preuves <ArrowUpRight size={16} /></a></div>
        </section>
      </main>

      <footer className="site-footer"><div className="container site-footer__inner"><div className="site-footer__brand"><span className="wordmark__mark"><img src={ASSETS.symbol} alt="" /></span><span><strong>MY LITTLE</strong><em>NIGHTMARE</em><small>Evidence room · archive fictionnelle</small></span></div><p>Une preuve de Black reste toujours active.</p><a className="evidence-secret-link" href={import.meta.env.BASE_URL + "dossier-interdit"} aria-label="Ouvrir le dossier interdit" title="Dossier interdit">◼ 07</a><span className="site-footer__code">MLN / EVIDENCE-ROOM</span></div></footer>

      {activeEvidence && <div className="lightbox evidence-lightbox" role="dialog" aria-modal="true" aria-label={`Examen de la preuve : ${activeEvidence.label}`} onClick={() => setActiveEvidence(null)}><div className="lightbox__panel evidence-lightbox__panel" onClick={(event) => event.stopPropagation()}><button className="lightbox__close" type="button" onClick={() => setActiveEvidence(null)} aria-label="Fermer l’examen"><X size={20} /></button><img src={activeEvidence.src} alt={activeEvidence.alt} /><div className="lightbox__caption"><span>{activeEvidence.code} · {activeEvidence.note}</span><strong>{activeEvidence.label}</strong></div></div></div>}
    </div>
  );
}
