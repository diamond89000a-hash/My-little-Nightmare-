// Direction artistique : salle d’archive interdite, charbon bleuté, ivoire de papier et cramoisi réservé aux alertes de Black.
import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, ArrowUpRight, Eye, KeyRound, LockKeyhole, Radio } from "lucide-react";

const ASSETS = { symbol: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/black-symbol_9d3fb021.png", horrorVideo: "https://mylittlenm-zzeo4fam.manus.space/manus-storage/horror-original-transmission_76b453bb.mp4" };

const STORAGE_PREFIX = "mln-nightmare-found-";
const UNLOCK_KEY = "mln-horror-unlocked";
const CODE = "HORROR";

const fragments = [
  { slug: "twilight", character: "Twilight Sparkle", letter: "H", title: "Les pages vierges" },
  { slug: "pinkie", character: "Pinkie Pie", letter: "O", title: "Le sucre rouge" },
  { slug: "rainbow", character: "Rainbow Dash", letter: "R", title: "Le ciel immobile" },
  { slug: "rarity", character: "Rarity", letter: "R", title: "La dernière collection" },
  { slug: "fluttershy", character: "Fluttershy", letter: "O", title: "La cabane" },
  { slug: "applejack", character: "Applejack", letter: "R", title: "La récolte noire" },
];

const chapters = [
  { character: "Dans Equestria", title: "Avant que la nuit ne parle", text: "Dans Equestria, Twilight Sparkle lisait dans sa bibliothèque, Pinkie Pie préparait des cupcakes à la fraise, Rainbow Dash traversait le ciel, Rarity dessinait ses prochaines créations, Fluttershy veillait sur les animaux et Applejack travaillait dans sa ferme. La journée semblait ordinaire. La nuit, elle, avait déjà choisi ses portes." },
  { character: "Les Mane Six", title: "Six rêves interrompus", text: "Quand elles s’endormirent, chacune se retrouva face à ce qui lui faisait le plus peur. Twilight découvrit des livres dont toutes les pages étaient vierges. Pinkie vit ses cupcakes changer et entendit ses amies derrière la porte de son sous-sol. Rainbow Dash battit des ailes dans un ciel immobile, incapable de décoller." },
  { character: "Les reflets", title: "Ce que le rêve déforme", text: "Rarity créa une collection parfaite, mais personne ne la regarda. Fluttershy suivit une trace jusqu’à une cabane et y aperçut une version inquiétante d’elle-même, dans un écho assumé à shed.mov. Applejack affronta les chauves-souris vampires de son verger, comme dans Bats!, mais sa colère finit par ne plus reconnaître les visages qu’elle voulait protéger." },
  { character: "Black", title: "La signature au bord du lit", text: "Au terme de chaque cauchemar, les six amies se réveillèrent en sursaut, trempées de sueur et incapables de distinguer le rêve du souvenir. Elles ne savaient pas encore qu’une même présence observait leurs peurs depuis l’autre côté du sommeil : Black, le dieu des cauchemars, qui les avait prises en grippe." },
  { character: "La suite", title: "Le cauchemar continue", text: "Cette nuit-là ne fut pas une fin. Black avait trouvé la forme exacte de leurs failles et comptait recommencer, encore et encore, jusqu’à ce qu’Equestria ne sache plus où s’arrêtait le rêve. L’archive s’interrompt ici, mais le signal, lui, demeure ouvert." },
];

export default function HorrorArchive() {
  const [visited, setVisited] = useState<Record<string, boolean>>({});
  const [code, setCode] = useState("");
  const [unlocked, setUnlocked] = useState(false);
  const [error, setError] = useState(false);

  useEffect(() => {
    const found = Object.fromEntries(fragments.map((fragment) => [fragment.slug, window.localStorage.getItem(`${STORAGE_PREFIX}${fragment.slug}`) === fragment.letter]));
    setVisited(found);
    setUnlocked(window.localStorage.getItem(UNLOCK_KEY) === "true");
  }, []);

  const foundCount = useMemo(() => fragments.filter((fragment) => visited[fragment.slug]).length, [visited]);
  const allFound = foundCount === fragments.length;

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!allFound) return;
    if (code.trim().toUpperCase() === CODE) {
      window.localStorage.setItem(UNLOCK_KEY, "true");
      setUnlocked(true);
      setError(false);
    } else {
      setError(true);
    }
  };

  return (
    <div className="horror-page">
      <header className="horror-header">
        <a className="wordmark" href={import.meta.env.BASE_URL + "site"} aria-label="Retour à My Little Nightmare"><span className="wordmark__mark"><img src={ASSETS.symbol} alt="" /></span><span className="wordmark__text"><strong>MY LITTLE</strong><em>NIGHTMARE</em></span></a>
        <span className="horror-header__status"><Radio size={13} /> Dossier scellé / 08</span>
      </header>

      <main>
        <section className="horror-hero">
          <div className="horror-hero__veil" />
          <div className="container horror-hero__inner">
            <a className="back-link" href={import.meta.env.BASE_URL + "site#cauchemars"}><ArrowLeft size={15} /> Retour aux cauchemars</a>
            <div className="horror-hero__copy">
              <p className="kicker">Restricted archive / 08 · Accès par fragments</p>
              <p className="horror-hero__eyebrow"><LockKeyhole size={13} /> Le mot que Black n’a pas effacé</p>
              <h1>Six lettres.<br /><em>Une histoire entière.</em></h1>
              <p className="horror-hero__lede">Les cauchemars ont laissé un alphabet dans leurs marges. Retrouvez chaque fragment, puis saisissez le mot qui ouvre le dossier original.</p>
            </div>
            <aside className="horror-hero__seal"><KeyRound size={22} /><span>CASE FILE / 08</span><strong>{unlocked ? "OPEN" : "SEALED"}</strong><small>{foundCount} / 6 fragments retrouvés<br />Code requis : 6 lettres</small></aside>
          </div>
          <div className="horror-hero__code">MLN / HORROR ARCHIVE / {unlocked ? "OPEN" : "SEALED"}</div>
        </section>

        <section className="horror-lock section-pad" aria-labelledby="horror-lock-title">
          <div className="container horror-lock__grid">
            <div className="section-label"><span>01</span><i /><span>Fragments collectés</span></div>
            <div className="horror-lock__main">
              <p className="kicker">Inventaire du mot secret</p>
              <h2 id="horror-lock-title">Reconstituez<br /><em>le signal.</em></h2>
              <p className="body-copy">Chaque page de cauchemar conserve une lettre. Les six fragments doivent être visités avant que le code puisse être accepté.</p>
              <div className="horror-evidence-slip" aria-label="Fragment visuel de Black"><div className="horror-evidence-slip__image"><img src={ASSETS.symbol} alt="" /></div><div><span className="horror-evidence-slip__stamp">TRACE / BLACK-00</span><p>Une marque rouge a survécu à l’effacement. Elle ne correspond à aucun dossier connu.</p></div><span className="horror-evidence-slip__edge">EYES<br />ONLY</span></div>
              <div className="horror-fragments" aria-label={`Fragments retrouvés : ${foundCount} sur 6`}>{fragments.map((fragment) => <a className={`horror-fragment ${visited[fragment.slug] ? "horror-fragment--found" : ""}`} href={`${import.meta.env.BASE_URL}cauchemar/${fragment.slug}`} key={fragment.slug}><span>{fragment.character}</span><strong>{visited[fragment.slug] ? fragment.letter : "?"}</strong><small>{visited[fragment.slug] ? "fragment retrouvé" : "dossier à ouvrir"}</small></a>)}</div>
              <form className="horror-form" onSubmit={handleSubmit}><div className="horror-form__apparatus"><span>AUTHENTIFICATION / DOSSIER 08</span><span>{allFound ? "SIGNAL COMPLET" : "SIGNAL INCOMPLET"}</span></div><label htmlFor="horror-code">Code de déverrouillage</label><div className="horror-form__row"><input id="horror-code" name="code" value={code} onChange={(event) => { setCode(event.target.value); setError(false); }} placeholder={allFound ? "Saisir les six lettres" : "Six fragments requis"} maxLength={6} autoComplete="off" disabled={!allFound || unlocked} aria-describedby="horror-status" /><button className="button button--primary" type="submit" disabled={!allFound || unlocked}><KeyRound size={15} /> {unlocked ? "Dossier ouvert" : "Déverrouiller"}</button></div><p id="horror-status" className={`horror-form__status ${error ? "horror-form__status--error" : ""}`}>{unlocked ? "Accès accordé. La transcription originale est disponible." : allFound ? "Les six fragments sont présents. Le mot est le code." : `Accès suspendu : ouvrez encore ${6 - foundCount} dossier${6 - foundCount > 1 ? "s" : ""}.`}</p></form>
            </div>
            <aside className="horror-lock__aside"><Eye size={17} /><blockquote>« Il ne suffit pas de trouver la peur. Il faut encore savoir comment elle s’écrit. »</blockquote><cite>— Annotation attribuée à Black</cite></aside>
          </div>
        </section>

        {unlocked && <section className="horror-story section-pad" aria-labelledby="horror-story-title">
          <div className="container"><div className="archive-bar archive-bar--dark"><span>Original transmission / 00</span><span>Recovered from the first telling</span></div><div className="horror-story__heading"><div className="section-label"><span>02</span><i /><span>La creepypasta originale</span></div><p className="kicker">Dossier déverrouillé · lecture complète</p><h2 id="horror-story-title">My Little<br /><em>Nightmare.</em></h2><p className="horror-story__intro">Ce texte restitue l’idée fondatrice de l’univers : six amies confrontées à leurs peurs, puis la révélation de Black, dieu des cauchemars.</p></div><section className="horror-video" aria-labelledby="horror-video-title"><div className="horror-video__meta"><span>Recovered transmission / 00</span><span>Lecture manuelle · MP4</span></div><div className="horror-video__frame"><video className="horror-video__player" controls preload="metadata" playsInline aria-describedby="horror-video-caption"><source src={ASSETS.horrorVideo} type="video/mp4" />Votre navigateur ne prend pas en charge la lecture vidéo.</video></div><div className="horror-video__caption" id="horror-video-caption"><div><p className="kicker">Preuve audiovisuelle · dossier ouvert</p><h3 id="horror-video-title">La transmission originale</h3></div><p>Le signal retrouvé après l’ouverture du dossier. Lecture non automatique : Black attend que vous lanciez la bande.</p></div></section><div className="horror-chapters">{chapters.map((chapter, index) => <article className="horror-chapter" key={chapter.title}><span className="horror-chapter__number">0{index + 1}</span><div><p className="kicker">{chapter.character}</p><h3>{chapter.title}</h3><p>{chapter.text}</p></div></article>)}</div><div className="horror-story__closing"><p className="kicker">Fin de l’archive originale</p><p>Tu as retrouvé le mot. Black, lui, savait déjà que tu finirais par le prononcer.</p><a className="button button--outline" href={import.meta.env.BASE_URL + "site"}>Refermer le dossier <ArrowUpRight size={16} /></a></div><div className="horror-discord" aria-labelledby="horror-discord-title"><p className="kicker">Transmission communautaire · accès autorisé</p><h3 id="horror-discord-title">Le signal continue sur Discord.</h3><p>Rejoins le groupe de l’univers de Black pour suivre les annonces, les créations et les prochains fragments du dossier.</p><a className="button button--primary" href="https://discord.gg/VeRpMD6Szg" target="_blank" rel="noreferrer noopener">Rejoindre le groupe Discord <ArrowUpRight size={16} /></a></div></div>
        </section>}

        <section className="horror-footer section-pad"><div className="container horror-footer__inner"><p className="kicker">{unlocked ? "Signal ouvert" : "Signal en attente"}</p><h2>{unlocked ? <>L’histoire est revenue.<br /><em>Le rêve aussi.</em></> : <>Toutes les lettres<br /><em>attendent leur lecteur.</em></>}</h2><a className="button button--outline" href={import.meta.env.BASE_URL + "site"}><ArrowLeft size={15} /> Quitter le dossier</a></div></section>
      </main>

      <footer className="site-footer"><div className="container site-footer__inner"><span>MY LITTLE NIGHTMARE / ARCHIVE FICTIONNELLE</span><span className="site-footer__code">HORROR / {unlocked ? "OPEN" : `${foundCount}/06`}</span></div></footer>
    </div>
  );
}
