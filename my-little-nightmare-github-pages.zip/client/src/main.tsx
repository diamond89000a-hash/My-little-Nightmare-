import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// GitHub Pages serves route directories with a trailing slash.
const base = import.meta.env.BASE_URL;
const current = window.location.pathname;
if (current !== base && current.endsWith('/')) {
  window.history.replaceState(null, '', current.slice(0, -1) + window.location.search + window.location.hash);
}
createRoot(document.getElementById("root")!).render(<App />);
