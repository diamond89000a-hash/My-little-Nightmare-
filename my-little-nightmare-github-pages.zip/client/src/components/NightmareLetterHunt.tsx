import { useEffect, useMemo, useState } from "react";
import { Eye } from "lucide-react";
import { useLocation } from "wouter";

const STORAGE_PREFIX = "mln-nightmare-code-";

const LETTER_BY_ROUTE = [
  { match: (path: string) => path === "/", letter: "N", label: "Lettre cachée dans le seuil" },
  { match: (path: string) => path === "/site", letter: "I", label: "Lettre cachée dans l’accueil" },
  { match: (path: string) => path === "/journal", letter: "G", label: "Lettre cachée dans le journal" },
  { match: (path: string) => path === "/preuves", letter: "H", label: "Lettre cachée dans les preuves" },
  { match: (path: string) => path === "/dossier-interdit", letter: "T", label: "Lettre cachée dans le dossier interdit" },
  { match: (path: string) => path === "/horror", letter: "M", label: "Lettre cachée dans l’archive Horror" },
  { match: (path: string) => path === "/rituel", letter: "A", label: "Lettre cachée dans le rituel" },
  { match: (path: string) => path === "/minecraft", letter: "R", label: "Lettre cachée dans les skins" },
  { match: (path: string) => path.startsWith("/cauchemar/"), letter: "E", label: "Lettre cachée dans un cauchemar" },
];

export const NIGHTMARE_LETTERS = LETTER_BY_ROUTE.map(({ letter }) => letter);

export default function NightmareLetterHunt() {
  const [location] = useLocation();
  const [found, setFound] = useState(false);
  const [notice, setNotice] = useState(false);
  const entry = useMemo(() => LETTER_BY_ROUTE.find(({ match }) => match(location)), [location]);

  useEffect(() => {
    setFound(entry ? window.localStorage.getItem(`${STORAGE_PREFIX}${entry.letter}`) === "true" : false);
    setNotice(false);
  }, [entry]);

  if (!entry) return null;

  const collect = () => {
    window.localStorage.setItem(`${STORAGE_PREFIX}${entry.letter}`, "true");
    setFound(true);
    setNotice(true);
    window.setTimeout(() => setNotice(false), 2800);
  };

  return (
    <>
      <button
        className={`nightmare-letter-hunt nightmare-letter-hunt--${entry.letter.toLowerCase()} ${found ? "nightmare-letter-hunt--found" : ""}`}
        type="button"
        onClick={collect}
        aria-label={found ? `${entry.label} : lettre ${entry.letter} déjà récupérée` : entry.label}
        title={found ? `Lettre ${entry.letter} récupérée` : "Quelque chose vous observe..."}
      >
        <Eye size={12} aria-hidden="true" />
        <span>{found ? entry.letter : "·"}</span>
      </button>
      {notice && <div className="nightmare-letter-notice" role="status">Fragment récupéré : <strong>{entry.letter}</strong></div>}
    </>
  );
}
