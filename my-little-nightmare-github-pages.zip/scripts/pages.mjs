import { mkdir, copyFile, readFile, writeFile, readdir, stat } from 'node:fs/promises';
import path from 'node:path';
const out = 'dist/public';
const base = process.env.PAGES_BASE || '/';
const origin = 'https://mylittlenm-zzeo4fam.manus.space';
// Use locally supplied media when available; otherwise retain the original public URL.
const media = JSON.parse(await readFile('scripts/media-list.json', 'utf8'));
async function walk(dir) {
  for (const e of await readdir(dir, {withFileTypes:true})) {
    const p = path.join(dir,e.name);
    if(e.isDirectory()) { if(e.name !== 'manus-storage') await walk(p); }
    else if(/\.(js|css|html)$/.test(p)) {
      let s = await readFile(p,'utf8');
      for(const name of media) {
        try { if((await stat(path.join(out,'manus-storage',name))).isFile()) s=s.replaceAll(`${origin}/manus-storage/${name}`,`${base}manus-storage/${name}`); } catch(e) { if(e.code !== 'ENOENT') throw e; }
      }
      await writeFile(p,s);
    }
  }
}
await walk(out);
const routes = ['site','journal','preuves','dossier-interdit','horror','rituel','minecraft','nightmare-archive','404', ...['twilight','pinkie','rainbow','rarity','fluttershy','applejack'].map(x=>'cauchemar/'+x)];
for(const route of routes) { const dir=path.join(out,route); await mkdir(dir,{recursive:true}); await copyFile(path.join(out,'index.html'),path.join(dir,'index.html')); }
await copyFile(path.join(out,'index.html'),path.join(out,'404.html'));
await writeFile(path.join(out,'.nojekyll'),'');
