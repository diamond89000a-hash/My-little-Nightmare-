import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';
import { defineConfig } from 'vite';
export default defineConfig({
  base: process.env.PAGES_BASE || '/',
  plugins: [react(), tailwindcss()],
  resolve: { alias: { '@': path.resolve(import.meta.dirname, 'client/src'), '@shared': path.resolve(import.meta.dirname, 'shared'), '@assets': path.resolve(import.meta.dirname, 'attached_assets') } },
  root: path.resolve(import.meta.dirname, 'client'),
  build: { outDir: path.resolve(import.meta.dirname, 'dist/public'), emptyOutDir: true },
  server: { host: true, port: 3000 },
});
